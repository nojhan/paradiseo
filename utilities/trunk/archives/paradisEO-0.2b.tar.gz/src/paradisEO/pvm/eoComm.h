// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoPvmComm_h
#define eoPvmComm_h

#include <vector>
#include <string>

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

#include <paradisEO/eoComm.h>

namespace Pvm {

  /** For the Parallel Virtual Machine */  
  class eoComm : public :: eoComm {
    
  public :
    
    /** Constructor */
    eoComm (int _argc,
	    char * _argv []) ;
    
    /** Destructor */
    virtual ~ eoComm () ;

    /** Sends a string-based
	message ... */
    void send (unsigned _tag,
	       unsigned _dest,
	       const std :: string & _str) ;
    
    /** Sends an output-stream-string based
	message ... */
    
#ifdef HAVE_SSTREAM
    void send (unsigned _tag,
	       unsigned _dest,
	       std :: ostringstream & _os) ;
#else
    void send (unsigned _tag,
	       unsigned _dest,
	       std :: ostrstream & _os) ;
#endif
    
    /** Receiving a string-based message ...
	(blocking) */
    void receive (unsigned _tag,
		  unsigned _src,
		  std :: string & _str) ;
    
    /** Probing incoming messages ...
	(non-blocking) */
    bool probe (unsigned _tag,
		unsigned _src) ;
    
    /** Probing incoming messages
	from any source (for a given tag) ...
	(non-blocking) */
    bool probeAnySource (unsigned _tag) ;
    
    /** Probing incoming messages
	from any source (for any tag) ... 
	(non-blocking) */
    bool probeAnyTagAnySource () ;
  
    /** Waiting incoming messages ...
	(blocking) */
    void waitAnyTagAnySource () ;
    
    /** What is the rank ???
	[0 - (size - 1)] */
    int rank () ;
    
    /** How many distributed
	nodes ? */
    int size () ; 
    
    /** Good bye :-) */
    void terminate () ;
       
  private :
    
    int len, rk ; // Size & rank 
    
    std :: vector <int> tids ; // Real tasks tids
    
    std :: vector <std :: string> file_names ;
    std :: vector <int> degrees ;
    
    int wait_buf_ID ;

    void loadSchema (const char * _file_name) ;
  } ;
}

#endif
