// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoChan.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <paradisEO/eoChan.h>
#include <paradisEO/eoChanChan.h>
#include <paradisEO/eoNamingChan.h>
#include <paradisEO/eoStopChan.h>

int eoChan :: countTag = 0 ;

eoComm * eoChan :: comm ;

std :: map <std :: string, eoChan *> eoChan :: mapChan ;

/* Some special
   channels */
eoChanChan * eoChan :: chanChan ;
eoNamingChan * eoChan :: namingChan ;
eoStopChan * eoChan :: stopChan ;

bool eoChan :: verbMode = true ; /* Should infos be displayed
				    about what occurs ? */

eoChan :: eoChan (const std :: string _str
		  ) : id (_str) {
  
  chanChan -> declare (this, _str) ;
 
  mapChan [_str] = this ;
}

void eoChan :: update () {
  
  // Nothing at this level :-)
}

void eoChan :: updateAll () {

  for (std :: map <std :: string, eoChan *> :: iterator it = mapChan.begin () ;
       it != mapChan.end () ;
       it ++)
    it -> second -> update () ;
}

std :: string eoChan :: className () const {
  
  return id ;
}

void eoChan :: use (eoComm & _comm) {
  
  // Selects comm.
  comm = & _comm ;
  
  /* Init. some special channels ...
     (that are often required) */
  chanChan = new eoChanChan ;
  namingChan = new eoNamingChan ;
  stopChan = new eoStopChan ;
}

void eoChan :: displayChannels (std :: ostream & _os) {
  
  _os << '<' ;
  for (std :: map <std :: string, eoChan *> :: iterator it = mapChan.begin () ;
       it != mapChan.end () ;
       it ++)
    _os << it -> second -> className () << ' ' ;
  
  _os << '>' << std :: endl ;
}

void eoChan :: setVerbose (bool _mode) {
  
  verbMode = _mode ;
}

bool eoChan :: verbose () {
  
  return verbMode ;
}

