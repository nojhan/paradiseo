// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoParaTasks.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoParaTasks_h
#define eoParaTasks_h

#include <vector>

#include <paradisEO/threads/eoTask.h>

/** It embedds a 'bag of tasks' to process
    concurrently ... */
class eoParaTasks : public std :: vector <eoTask *> {
  
public :
  
  /** Constructor */
  eoParaTasks () ;
  
  /** It runs tasks ! */
  void launch () ;

  /** ? */
  //  void push_back (eoTask & _task) ;

private :
  
  static void * runTask (void * _arg) ;
  
  static int numTask ;

  pthread_mutex_t mutex ; // For sync.

} ;

#endif
