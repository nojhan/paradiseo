// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoParaTasks.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <pthread.h>

#include <paradisEO/threads/eoParaTasks.h>

int eoParaTasks :: numTask = 0 ;

eoParaTasks :: eoParaTasks () {
  
  pthread_mutex_init (& mutex, NULL) ;
}

void eoParaTasks :: launch () {
  
  pthread_t * thr = new pthread_t [size ()] ;
  
  for (unsigned i = 0 ; i < size () ; i ++) {    
    pthread_create (& thr [i], 0, runTask, this) ;
    pthread_mutex_lock (& mutex) ;
  }
  
  for (unsigned i = 0 ; i < size () ; i ++)
    pthread_join (thr [i], 0) ;
  
  delete [] thr ;
}

/*
void eoParaTasks :: push_back (eoTask & _task) {
  
  std :: vector <eoTask *> :: push_back (& _task) ;
}
*/
void * eoParaTasks :: runTask (void * _argv) {
  
  eoParaTasks * tasks = (eoParaTasks *) _argv ;
  
  int num = tasks -> numTask ++ ;
  
  pthread_mutex_unlock (& tasks -> mutex) ;

  tasks -> operator [] (num) -> operator () () ;
  
  return 0 ;
} 
