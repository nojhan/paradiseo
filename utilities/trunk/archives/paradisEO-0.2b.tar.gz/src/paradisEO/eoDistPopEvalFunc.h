// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistPopEvalFunc.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistPopEvalFunc_h
#define eoDistPopEvalFunc_h

#include <eoPopEvalFunc.h>

#include <paradisEO/eoPopChan.h>
#include <paradisEO/eoFitChan.h>

/** ???*/
template <class EOT> class eoDistPopEvalFunc : public eoPopEvalFunc <EOT> {
  
public :
  
  // Alias
  typedef typename EOT :: Fitness Fitness ;

  /** Constructor. */
  eoDistPopEvalFunc (eoPopChan <EOT> & _popChan,
		     eoFitChan <EOT> & _fitChan,
		     std :: vector <std :: string> & _vectLabels,
		     eoUF <const std :: vector <Fitness> &, Fitness> & _reduceEval
		     ) :
    popChan (_popChan),
    fitChan (_fitChan),
    vectLabels (_vectLabels),
    reduceEval (_reduceEval) {
    
  }
 
  void operator () (eoPop <EOT> & _parents,
		    eoPop <EOT> & _offspring) {

    /* Notes. '_parents' is discarded ! (See. TimeVarying ...)
       Individuals in a population will be mixed */
  
    // Initialisation
    for (unsigned i = 0 ; i < vectLabels.size () ; i ++)
      eoChan :: namingChan -> wait (vectLabels [i]) ;
            
    /* Broadcasting 
       the population ... */
    for (unsigned i = 0 ; i < vectLabels.size () ; i ++)
      
      for (unsigned j = 0 ; j < eoChan :: namingChan -> size () ; j ++)
	
	if (eoChan :: namingChan -> operator [] (j) == vectLabels [i]) {
	  popChan.send (j, _offspring) ;
	  if (eoChan :: verbose ()) {
	    std :: cout << "    [<" << j << "> " << eoChan :: namingChan -> operator [] (j) ;
	    std :: cout << "] (" << _offspring.size () << ')' << std :: endl ;
	  }
	  break ;
	}
    
    std :: vector <std :: vector <Fitness> > vectFit ; 
    
    vectFit.resize (_offspring.size ()) ;

    if (eoChan :: verbose ())
      std :: cout << "## Distributing pop. for partial evaluations ..." << std :: endl ;
        
    for (unsigned i = 0 ; i < vectLabels.size () ; i ++) {
      
      fitChan.wait () ;
      
      for (unsigned j = 0 ; j < fitChan.size () ; j ++)
	
	if (! fitChan [j].empty ()) {
	    
	  std :: vector <Fitness> & imm = fitChan [j].front () ;
	  for (unsigned k = 0 ; k < imm.size () ; k ++)
	    vectFit [k].push_back (imm [k]) ;
	  fitChan [j].pop () ;	  
	  break ;
	}
    }

    /* Updating fitnesses
       (i.e aggregation) ... */
    Fitness fit ;
    for (unsigned i = 0 ; i < _offspring.size () ; i ++) {
      fit = reduceEval (vectFit [i]) ;
      _offspring [i].fitness (fit) ;
    }
  }
  
private :
  
  eoPopChan <EOT> & popChan ;
  
  eoFitChan <EOT> & fitChan ;
  
  std :: vector <std :: string> & vectLabels ;
  
  eoUF <const std :: vector <Fitness> &, Fitness> & reduceEval ;

} ;

#endif

