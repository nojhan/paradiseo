// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoStopChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <paradisEO/eoStopChan.h>
#include <paradisEO/eoNamingChan.h>

eoStopChan :: eoStopChan () : eoChan ("eoStopChan"),
			      thisIsTheEnd (false),
			      howManyAreAlive (comm -> size () - 1) {
  
  // Nothing else ...
}

void eoStopChan :: destroy (unsigned _dest) {
  
  comm -> send (tag, _dest, "That's over for you :-) !!!") ;
}

void eoStopChan :: destroy (const std :: string & _dest) {
  
  for (int i = 0 ; i < comm -> size () ; i ++)
    if (namingChan -> operator [] (i) == _dest)
      destroy (i) ;
}

void eoStopChan :: destroyAll () {
  
  for (int i = 0 ; i < comm -> size () ; i ++)
    if (i != comm -> rank ())
      destroy (i) ;
}

void eoStopChan :: update () {
  
  while (comm -> probeAnySource (tag)) 
    
    for (int i = 0 ; i < comm -> size () ; i ++) 
      
      if (comm -> probe (tag, i)) {
	
	std :: string str ;
	comm -> receive (tag, i, str) ;
	
	if (str == "That's over for you :-) !!!")
	  thisIsTheEnd = true ;
	
	else { // That's over for me :-) !!! 
	  howManyAreAlive -- ;
	}      
      } 
}

bool eoStopChan :: over () {
  
    return thisIsTheEnd ;
}

void eoStopChan :: notifyTermination () {

  if (verbose ()) {
    
    std :: cout << "## Finalization ..." << std :: endl ;
    
    // From ...
    std :: cout << "    for [<"  ;
    std :: cout << eoChan :: comm -> rank () ;
    std :: cout << "> " << eoChan :: namingChan -> operator [] (eoChan :: comm -> rank ()) ;
    std :: cout << "]" << std :: endl ;
  }
  
  for (int i = 0 ; i < comm -> size () ; i ++)
    if (i != comm -> rank ())
      comm -> send (tag, i, "That's over for me :-) !!!") ;
}

bool eoStopChan :: terminationAllowed () {
  
  return ! howManyAreAlive ;
}
