// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistIslandMig.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistIslandMig_h
#define eoDistIslandMig_h

#include <string>
#include <vector>

#include <eoContinue.h>
#include <eoSelect.h>
#include <eoReplacement.h>

#include <paradisEO/eoPopChan.h>
#include <paradisEO/eoTopology.h>

/** ??? */
template <class EOT> class eoDistAsyncIslandMig : public eoContinue <EOT> {
  
public :
 
  /** Constructor */
  eoDistAsyncIslandMig (eoContinue <EOT> & _cont,
			eoPopChan <EOT> & _popChan,
			eoContinue <EOT> & _contMig,		   
			eoSelect <EOT> & _select,
			eoReplacement <EOT> & _replace,
			eoTopology & _topo
			) : 
    cont (_cont),
    popChan (_popChan),
    contMig (_contMig),
    select (_select),
    replace (_replace),
    topo (_topo) {
    
  }
  
  bool operator () (const eoPop <EOT> & _pop) {
    /* Warning !!! The 'const' is discarded. Not nice at all :-/
       But I don't think there is a better way
       to maintain the code easy  :-) */ 
    
    // Updating incoming messages ...
    
    eoChan :: updateAll () ;
    for (unsigned i = 0 ; i < popChan.size () ; i ++)
      while (! popChan [i].empty ()) {
	eoPop <EOT> & imm = popChan [i].front () ;
	
	if (imm.empty ()) {
	  /* Meaning a need of
	     immigration was received ! */
	  
	  //	  std :: cout << "Reception besoin d'immigration en " << eoChan :: comm -> rank () << std :: endl ;
	  eoPop <EOT> emm ;
	  select (_pop, emm) ;
	  popChan.send (i, emm) ;
	  
	}
	else {
      
	  // New immigrants to integrate into the current local population
	  // Ouch ;-/ The following line is really ugly :-)
	  replace (((eoPop <EOT> &)_pop), imm) ;
	  
	  if (eoChan :: verbose ()) {
	    std :: cout << "## Migration ..." << std :: endl ;

	    // From ...
	    std :: cout << "    from [<"  ;
	    std :: cout << eoChan :: comm -> rank () ;
	    std :: cout << "> " << eoChan :: namingChan -> operator [] (eoChan :: comm -> rank ()) ;
	    // To ...
	    std :: cout << "] to [<"  ;
	    std :: cout << i ;
	    std :: cout << "> " << eoChan :: namingChan -> operator [] (i) ;
	    std :: cout << ']' << std :: endl ;  
	  }
	}
	popChan [i].pop () ;
      }
    
    /* About the need of immigration of new
       neighbouring individuals for
       the current pop. */
    
    if (! contMig (_pop)) {

      eoPop <EOT> needImm ; /* An empty pop. !, that will be
			       considered as a need of immigration */      
            
      // Emigrants
      std :: vector <unsigned> neigh_in, neigh_out ;
      topo (neigh_in, neigh_out) ;
      
      for (unsigned i = 0 ; i < neigh_out.size () ; i ++) {
	eoPop <EOT> emm ;
	select (_pop, emm) ;
	popChan.send (neigh_out [i], emm) ;
      }


    }
    return cont (_pop) ;
  }
  
private :

  eoContinue <EOT> & cont ; // Global continuator of the E.A.
  
  eoPopChan <EOT> & popChan ; // Pop. channel
  
  eoContinue <EOT> & contMig ; // To express a need of immigration
  
  eoSelect <EOT> & select ; // To select emigrants
  eoReplacement <EOT> & replace ; // To integrate immigrants
  
  eoTopology & topo ; // The used topology
} ;

#endif
