// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoPopSolver.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoPopSolver_h
#define eoPopSolver_h

#include <eoAlgo.h>
#include <eoPop.h>

#include <paradisEO/eoPopChan.h>

/** ??? */
template <class EOT> class eoPopSolver : public eoF <void> {
  
public :
  
  /** Constructor */
  eoPopSolver (eoPopChan <EOT> & _popChan,
	       eoAlgo <EOT> & _algo
	       ) : popChan (_popChan),
		   algo (_algo) {
    
  }
  
  /** Action */
  void operator () () {
    
    eoPop <EOT> pop ;
    
    while (true) {
      
      popChan.wait () ;
      
      for (unsigned i = 0 ; i < popChan.size () ; i ++)
	if (! popChan [i].empty ()) {
	  
	  pop = popChan [i].front () ;
	  popChan [i].pop () ;
	  
	  algo (pop) ;
	  popChan.send (i, pop) ;
	  
	}   
    }
  }
  
private :
  
  eoPopChan <EOT> & popChan ; // Population channel
  
  eoAlgo <EOT> & algo ; // Pop. applied algorithm
  
} ;

#endif
