// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoComm_h
#define eoComm_h

#include <string>
#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

/** An abstract interface for
    communication library */  
class eoComm {
  
public :
      
  /** Sends a string-based
      message ... */
  virtual void send (unsigned _tag,
		     unsigned _dest,
		     const std :: string & _str) = 0 ;
  
  /** Sends an output-stream-string based
      message ... */
  
#ifdef HAVE_SSTREAM
  virtual void send (unsigned _tag,
		     unsigned _dest,
		     std :: ostringstream & _os) = 0 ;
  
#else
  virtual void send (unsigned _tag,
		     unsigned _dest,
		     std :: ostrstream & _os) = 0 ;
#endif

  /** Receiving a string-based message ...
      (blocking) */
  virtual void receive (unsigned _tag,
			unsigned _src,
			std :: string & _str) = 0 ;
    
  /** Probing incoming messages ...
      (non-blocking) */
  virtual bool probe (unsigned _tag,
		      unsigned _src) = 0 ;
  
  /** Probing incoming messages
      from any source (for a given tag) ...
      (non-blocking) */
  virtual bool probeAnySource (unsigned _tag) = 0 ;    

  /** Probing incoming messages
      from any source (for any tag) ... 
      (non-blocking) */
  virtual bool probeAnyTagAnySource () = 0 ;
  
  /** Waiting incoming messages ...
      (blocking) */
  virtual void waitAnyTagAnySource () = 0 ;
  
  /** What is the rank ???
      [0 - (size - 1)] */
  virtual int rank () = 0 ;
  
  /** How many distributed
      nodes ? */
  virtual int size () = 0 ; 
  
  /** Good bye :-) */
  virtual void terminate () = 0 ;
   
} ;

#endif
