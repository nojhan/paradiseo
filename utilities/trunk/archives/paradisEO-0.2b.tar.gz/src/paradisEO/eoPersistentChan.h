// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoPersistentChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoPersistentChan_h
#define eoPersistentChan_h

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

#include <eoPersistent.h>

#include <paradisEO/eoSerialChan.h>

/** */
template <class T> class eoPersistentChan : public eoSerialChan <T> {

public :
  
  /** Constructor */
  eoPersistentChan (std :: string _className
		    ) : eoSerialChan <T> (_className) { 
  }
  
private :
  
  /** Stores a T object to
      a string representation */
  void serialize (const T & _t,
		  std :: string & _str) {
    
#ifdef HAVE_SSTREAM
    std :: ostringstream os ;
#else
    std :: ostrstream os ;
#endif

    _t.printOn (os) ;
    os << '\0' ;
    _str = os.str () ;
  }
  
  /** Creates a T object from
      a stored representation */
  void unserialize (T & _t,
		    const std :: string & _str) {
    
#ifdef HAVE_SSTREAM    
    std :: istringstream is (_str.c_str ()) ;
#else
    std :: istrstream is (_str.c_str ()) ;
#endif

    _t.readFrom (is) ;
  } 

} ;

#endif
 
