// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoMpiComm_h
#define eoMpiComm_h

#include <paradisEO/eoComm.h>
#include <utils/eoParser.h>

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

/** For the Message Passing Interface
   (MPI) */

namespace Mpi {
  
  class eoComm : public :: eoComm {
    
  public :
            
    eoComm (int * _argc,
	    char * * _argv []) ;
    
    void send (unsigned _tag,
	       unsigned _dest,
	       const std :: string & _str) ;
    
#ifdef HAVE_SSTREAM
    void send (unsigned _tag,
	       unsigned _dest,
	       std :: ostringstream & _os) ;
#else
    void send (unsigned _tag,
	       unsigned _dest,
	       std :: ostrstream & _os) ;
#endif
    
    void receive (unsigned _tag,
		  unsigned _src,
		  std :: string & _str) ;
    
    bool probe (unsigned _tag,
		unsigned _src) ;
    
    bool probeAnySource (unsigned _tag) ;    
    
    bool probeAnyTagAnySource () ;
    
    void waitAnyTagAnySource () ;
    
    int rank () ;
    
    int size () ; 
    
    void terminate () ;

  private :
       
    int len, rk ; // Size & Rank ...
  } ;
} 

#endif
