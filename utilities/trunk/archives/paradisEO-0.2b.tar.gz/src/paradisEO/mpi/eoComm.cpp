// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <paradisEO/mpi/eoComm.h>
#include <paradisEO/eoChan.h>
#include <paradisEO/eoStopChan.h>

#include <mpi.h>

namespace Mpi {

  eoComm :: eoComm (int * _argc,
		    char * * _argv []) {

    MPI_Init (_argc, _argv) ; // To be done once :-)     
   
    MPI_Comm_size (MPI_COMM_WORLD, & len) ; // How many ?
    MPI_Comm_rank (MPI_COMM_WORLD, & rk) ; // Who am I ?
  }
    
  void eoComm :: send (unsigned _tag,
		       unsigned _dest,
		       const std :: string & _str) {
    
    MPI_Send ((char *) _str.c_str (), _str.size () + 1, MPI_CHAR, _dest, _tag, MPI_COMM_WORLD) ;
  }
  
#ifdef HAVE_SSTREAM
  void eoComm :: send (unsigned _tag,
		       unsigned _dest,
		       std :: ostringstream & _os) {
    _os << '\0' ;
    send (_tag, _dest, _os.str ()) ;
  }
  
#else
  void eoComm :: send (unsigned _tag,
		       unsigned _dest,
		       std :: ostrstream & _os) {
    _os << '\0' ;
    send (_tag, _dest, _os.str ()) ;

  }
#endif

  void eoComm :: receive (unsigned _tag,
			  unsigned _src,
			  std :: string & _str) {
    
    MPI_Status stat ;
    int len ;
    
    MPI_Probe (_src, _tag, MPI_COMM_WORLD, & stat) ;
    MPI_Get_count (& stat, MPI_CHAR, & len) ;
    
    char * buff = new char [len] ;
    
    MPI_Recv (buff, len, MPI_CHAR, _src, _tag, MPI_COMM_WORLD, & stat) ;
    _str.assign (buff) ;
    
    delete [] buff ;
  }
  
  bool eoComm :: probe (unsigned _tag,
			unsigned _src) {
    
    MPI_Status stat ;
    int flag ;
    
    MPI_Iprobe (_src, _tag, MPI_COMM_WORLD, & flag, & stat) ;

    return flag ;
  }
    
  bool eoComm :: probeAnySource (unsigned _tag) {
    
    MPI_Status stat ;
    int flag ;
  
    MPI_Iprobe (MPI_ANY_SOURCE, _tag, MPI_COMM_WORLD, & flag, & stat) ;
  
    return flag ;
  } 
    
  bool eoComm :: probeAnyTagAnySource () {
    
    MPI_Status stat ;
    int flag ;

    MPI_Iprobe (MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, & flag, & stat) ;

    return flag ;
  }

  void eoComm :: waitAnyTagAnySource () {
    
    MPI_Status stat ;

    MPI_Probe (MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, & stat) ;
  }
    
  int eoComm :: rank () {

    return rk ;
  }
  
  int eoComm :: size () {
    
    return len ;
  }
  
  void eoComm :: terminate () {
    
    eoChan :: stopChan -> notifyTermination () ;
    while (! eoChan :: stopChan -> terminationAllowed ()) {
      
      waitAnyTagAnySource () ;
      eoChan :: updateAll () ;
    }
    MPI_Finalize () ;    
  }
} 


