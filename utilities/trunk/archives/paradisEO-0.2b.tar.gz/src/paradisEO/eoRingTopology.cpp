// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoRingTopology.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <paradisEO/eoRingTopology.h>
#include <paradisEO/eoNamingChan.h>

eoRingTopology :: eoRingTopology () {
  
  // Nothing !
}
  

eoRingTopology :: eoRingTopology (const std :: string & __label) {
  
  eoChan :: namingChan -> publish (__label) ;
}

void eoRingTopology :: operator () (std :: vector <unsigned> & __in, std :: vector <unsigned> & __out) {
  
  eoNamingChan & namingChan =  * eoChan :: namingChan ;

  std :: string & label =  namingChan [eoChan :: comm -> rank ()] ;
  
  // Incoming
  for (unsigned i = (eoChan :: comm -> rank () + 1) % eoChan :: comm -> size () ;
       i != eoChan :: comm -> rank () ;
       i = (i + 1) % eoChan :: comm -> size ()) {
    
    if (namingChan [i] == label) {
      
      __in.clear () ;
      __in.push_back (i) ;
     
      break ;
    } 
  }
  
  // Outcoming
  for (unsigned i = (eoChan :: comm -> rank () - 1 + eoChan :: comm -> size ()) % eoChan :: comm -> size () ;
       i != eoChan :: comm -> rank () ;
       i = (i - 1 + eoChan :: comm -> size ()) % eoChan :: comm -> size ()) {
    
    if (namingChan [i] == label) {
      
      __out.clear () ;
      __out.push_back (i) ;
      
      break ;
    } 
  }

}
