// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoSerialChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoSerialChan_h
#define eoSerialChan_h

#include <queue>
#include <vector>

#include <paradisEO/eoChan.h>
#include <paradisEO/eoNamingChan.h>

/** A generic class to send/receive some kind of data that
    are said to be 'serializable' */
template <class T> class eoSerialChan : public eoChan, public std :: vector <std :: queue <T> > {
  
public :
  
  /** Constructor */
  eoSerialChan (std :: string _className
		) : eoChan (_className) {
    
    resize (comm -> size ()) ;
  }
  
  /** Processing incoming messages ...
      -> Receives some pop. of solutions */
  void update () {
    
    while (comm -> probeAnySource (tag)) {
      
      for (unsigned i = 0 ; i < size () ; i ++) {
	if (comm -> probe (tag, i)) {
	  operator [] (i).push (T ()) ;
	  std :: string str ;
	  comm -> receive (tag, i, str) ;
	 
	  unserialize (operator [] (i).back (), str) ;
	}
      }
    }
  }
  
  /** Is there at least one
      stored population ??? */
  bool probeAnySource () {
    
    updateAll () ;
    
    for (unsigned i = 0 ; i < size () ; i ++)
      if (! operator [] (i).empty ())
	return true ;
    return false ;
  }

  /** */
  bool probe (unsigned _src) {
    
    updateAll () ;

    return ! operator [] (_src).empty () ;
  }

  /** */
  bool probe (const std :: string & _src) {
    
    updateAll () ;
    
    for (unsigned i = 0 ; i < size () ; i ++)
      if (namingChan -> operator [] (i) == _src && ! operator [] (i).empty ())
	return true ;
    return false ;
  }
  
  /** Sends the given 'T' object */
  void send (unsigned _dest,
	     const T & _t) {
    
    std :: string str ;
    
    serialize (_t, str) ;
    comm -> send (tag, _dest, str) ;
  }

  /** */
  void send (std :: string & _dest,
	     const T & _t) {
    
    for (unsigned i = 0 ; i < size () ; i ++)
      if (namingChan -> operator [] (i) == _dest)
	send (i, _t) ;
  }
  
  /** ? */
  void wait () {
    
    updateAll () ;
    
    while (! probeAnySource ()) {
      
      comm -> waitAnyTagAnySource () ;
      updateAll () ;      
    } 
  }

  /** ? */
  void wait (unsigned _src) {
       
    updateAll () ;

    while (! probe (_src)) {
      
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    }
  }

  /** */
  void sendLeader (const T & _t) {
    
    send (0, _t) ;
  } 
 
  /** ? */
  void gather (unsigned _how_many, std :: vector <T> & _vect_T) {
    
    unsigned n = 0 ;
    
    _vect_T.clear () ;
    while (n != _how_many) {
      
      this -> wait () ;  
      for (unsigned i = 0 ; i < size () ; i ++)	
	while (! operator [] (i).empty ()) {
	  
	  _vect_T.push_back (operator [] (i).front ()) ;
	  operator [] (i).pop () ;
	  n ++ ;
       	}
      
    }
  }
            
protected :
  
  /** Stores a T object to
      a string representation */
  virtual void serialize (const T & _t,
			  std :: string & _str) = 0 ;
  
  /** Creates a T object from
      a stored representation */
  virtual void unserialize (T & _t,
			    const std :: string & _str) = 0 ;
  
} ;

#endif
