// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoFitChan.h"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoFitChan_h
#define eoFitChan_h

#include <eoPop.h>

#include <paradisEO/eoSerialChan.h>

/** ? */
template <class EOT> class eoFitChan : public eoSerialChan <std :: vector <typename EOT :: Fitness> > {
  
  // Nothing ! Just an alias :-)
  
public :
  
  /** Constructor */
  eoFitChan (std :: string _className = ""
	     ) : eoSerialChan <std :: vector <typename EOT :: Fitness> > ("eo" + _className + "Fit") {
    
  }
  
private :
  
  /** Stores a population of 'Fitnesses' object to
      a string representation */
  void serialize (const std :: vector <typename EOT :: Fitness> & _vect_fit,
		  std :: string & _str) {
    
#ifdef HAVE_SSTREAM
    std :: ostringstream os ;
#else
    std :: ostrstream os ;
#endif
    
    os << _vect_fit.size () << ' ' ;
    
    std :: copy (_vect_fit.begin(),
		 _vect_fit.end(),
		 std :: ostream_iterator <typename EOT :: Fitness> (os, " ")) ;
    
    os << '\0' ;
    
    _str = os.str () ;
  }
  
  /** Creates a population of 'Fitnesses' object from
      a stored representation */
  void unserialize (std :: vector <typename EOT :: Fitness> & _vect_fit,
		    const std :: string & _str) {
    
#ifdef HAVE_SSTREAM
    std :: istringstream is (_str.c_str ()) ;
#else    
    std :: istrstream is (_str.c_str ()) ;
#endif

    unsigned len ;
    is >> len ;

    _vect_fit.resize (len) ;
    
    for (unsigned i = 0 ; i < len ; i ++) {
      
      typename EOT :: Fitness fit ;
      is >> fit ;
      _vect_fit [i] = fit ;
    }
  }
} ;

#endif
