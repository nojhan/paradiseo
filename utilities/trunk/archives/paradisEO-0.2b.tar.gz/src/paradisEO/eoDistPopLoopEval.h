// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistPopLoopEval.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistPopLoopEval_h
#define eoDistPopLoopEval_h

#include <eoPopEvalFunc.h>

#include <paradisEO/eoNamingChan.h>
#include <paradisEO/eoPopChan.h>
#include <paradisEO/eoFitChan.h>

/** ? */
template <class EOT> class eoDistPopLoopEval : public eoPopEvalFunc <EOT> {

public :
  
  /** Constructor */
  eoDistPopLoopEval (eoPopChan <EOT> & _popChan,
		     eoFitChan <EOT> & _fitChan,
		     std :: string _label, // Of the evaluating nodes
		     unsigned _grain = 1 // Granularity
		     ) : popChan (_popChan),
			 fitChan (_fitChan),
			 label (_label),
			 grain (_grain) {    
  }
  
  /** For a population of parents
      and children */
  void operator () (eoPop <EOT> & _parents,
		    eoPop <EOT> & _offspring) {
    /* Notes. '_parents' is discarded ! (See. TimeVarying ...)
       Individuals in a population will be mixed */
    
    eoPop <EOT> emm ;
    
    std :: vector <typename EOT :: Fitness> imm ;
    
    /* Solutions that are sent ...
       ... and received later */
    
    unsigned pos = 0, num_back = 0 ;

    std :: vector <bool> busy (popChan.size (), false) ;
    
    std :: vector <unsigned> begin_pos (popChan.size ()) ;

    // Initialisation
    eoChan :: namingChan -> wait (label) ; // Needs at least one eval. node.
    
    bool first_time = true ;

    if (eoChan :: verbose ())
      std :: cout << "## Distributing pop. for evaluation ..." << std :: endl ;
    
    while (num_back < _offspring.size ()) {
      
      if (! first_time) {
	
	fitChan.wait () ;
       
	for (unsigned i = 0 ; i < popChan.size () ; i ++)
	  if (! fitChan [i].empty ()
	      && eoChan :: namingChan -> operator [] (i) == label) {
	    
	    imm = fitChan [i].front () ;
	    fitChan [i].pop () ;
	    busy [i] = false ;
	    
	    // Reinsertion
	    for (unsigned j = 0 ; j < imm.size () ; j ++)
	      _offspring [begin_pos [i] + j].fitness (imm [j]) ;
	    num_back += imm.size () ;
	  }
      }
      
      /* Any more individuals
	 to send ? */
      for (unsigned i = 0 ; i < eoChan :: namingChan -> size () ; i ++)
	if (eoChan :: namingChan -> operator [] (i) == label
	    && pos < _offspring.size ()
	    && ! busy [i]) {
	  
	  // Chunk
	  busy [i] = true ;
	  begin_pos [i] = pos ;
	  
	  emm.clear () ;
	  for (unsigned j = 0 ; j < grain && pos < _offspring.size () ; j ++)
	    emm.push_back (_offspring [pos ++]) ;
	  
	  popChan.send (i, emm) ;
	  if (eoChan :: verbose ()) {
	    std :: cout << "    [<" << i << "> " << eoChan :: namingChan -> operator [] (i) ;
	    std :: cout << "] (" << emm.size () << ')' << std :: endl ;
	  }
	}
      
      first_time = false ;
    }
  }

private :
  
  eoPopChan <EOT> & popChan ; // Pop. channel

  eoFitChan <EOT> & fitChan ; // Fitness channel
  
  std :: string label ; // Of the evaluating nodes
  
  unsigned grain ; // Granularity
    
} ;

#endif
