// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoChanChan.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <paradisEO/eoChanChan.h>

std :: map <std :: string, int> eoChanChan :: mapTag ;

eoChanChan :: eoChanChan () : eoChan ("eoChanChan") {
  
}

void eoChanChan :: declare (eoChan * _chan,
			    const std :: string _className) {
  
  if (! countTag || // Channel of channels ;-)
      ! comm -> rank ()) { // The "Master" process
        
    /* rank () -> 0 "Master". Initialization of the listener's tag
       from the shared tag count, which is then updated */
    _chan -> tag = countTag ++ ; // Post inc. 
    mapTag [_className] = _chan -> tag ;
  }
  else if (mapTag [_className])
    _chan -> tag = mapTag [_className] ;
  
  else {
    // Not used yet ...

    // Sending a request to the master ...
    comm -> send (tag, 0, _className) ;
    
    // Waiting for sync. to be done ... 
    blocked = true ;
    
    while (blocked) {
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    }      
    
    _chan -> tag = machinchouette ;
    mapTag [_className] = _chan -> tag ;
  }
}

void eoChanChan :: update () {
    
  if (! comm -> rank ()) {
    /* Master [0].
       Receiving a request for eoComm id. ... */
    
    while (comm -> probeAnySource (tag)) {
      for (int i = 0 ; i < comm -> size () ; i ++)
	if (comm -> probe (tag, i)) {
	  
	  std :: string str ;
	  
	  comm -> receive (tag, i, str) ;	    
	 
	  if (! mapTag [str])
	    mapTag [str] = countTag ++ ;
	  
#ifdef HAVE_SSTREAM
	  std :: ostringstream os ;
#else
	  std :: ostrstream os ;
#endif
	  os << mapTag [str] ;
	  comm -> send (tag, i, os) ;
	}
    }
  }
  else if (comm -> probe (tag, 0)) {
    /* Receiving the response
       of the master */
    
    std :: string str ;
    
    comm -> receive (tag, 0, str) ;
    machinchouette = atoi (str.data ()) ; // :-)
    blocked = false ;
  }
}
