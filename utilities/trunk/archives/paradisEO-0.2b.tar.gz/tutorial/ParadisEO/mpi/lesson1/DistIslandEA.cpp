#include <paradiseo.h>
#include <ga.h>

#include "binary_value.h"

// Size for tournament selection
#define T_SIZE 3 

// Number of bits in genotypes
#define VEC_SIZE 8

// Size of population
#define POP_SIZE 20 

// Maximum number of generation before STOP
#define MAX_GEN 3000 

// Crossover probability
#define P_CROSS 0.8	

// Mutation probability
#define P_MUT 1.0	

// Internal probability for bit-flip mutation
#define P_MUT_PER_BIT 0.01	

typedef eoBit <double> Indi ;

int main (int _argc, char * * _argv) {
  
  // Fitness function
  eoEvalFuncPtr <Indi, double, const std :: vector <bool> &> eval (binary_value) ;

  // Initilisation of population
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen) ;
  eoPop <Indi> pop (POP_SIZE, random) ;
  
  // Deterministic tournament selection
  eoDetTournamentSelect <Indi> selectOne (T_SIZE) ;
  eoSelectPerc <Indi> select (selectOne) ; 

  // Generational replacement
  eoGenerationalReplacement <Indi> replace; 

  // Uniform crossover
  eoUBitXover <Indi> xover ;
  
  // Standard bit-flip mutation
  eoBitMutation <Indi>  mutation (P_MUT_PER_BIT) ;

  /* Operators are encapsulated into an
     eoTransform object */
  eoSGATransform <Indi> transform (xover, P_CROSS, mutation, P_MUT) ;

  // Termination condition: stop after MAX_GEN generations
  eoGenContinue <Indi> genCont(MAX_GEN) ;

  // ParadisEO
  
  // To express a need of immigration
  eoFreqGenContinue <Indi> migCont (100) ; 
  
  /* How to select emigrants from
     the current population ? */
  eoRandomSelect <Indi> migSelectOne ;
  eoSelectPerc <Indi> migSelect (migSelectOne, 0.1) ; 
  
  /** How to assimilate immigrants into
      the current population ? */
  eoPlusReplacement <Indi> migReplace ;
  
  Mpi :: eoComm comm (& _argc, & _argv) ;
  eoChan :: use (comm) ;
  
  eoPopChan <Indi> popChan ;
  
  eoRingTopology topo ("Mars") ;

  eoDistAsyncIslandMig <Indi> continuator (genCont, popChan, migCont, migSelect, migReplace, topo) ;
  //eoDistSyncIslandMig <Indi> continuator (genCont, popChan, 100, migSelect, migReplace, topo) ;

  // Random seed
  rng.reseed (comm.rank ()) ; 
  
  /* An easy evolutionary algorithm
     to finish ... */ 
  eoEasyEA <Indi> gga (continuator, eval, select, transform, replace) ;

  gga (pop) ;

  comm.terminate () ; 
    
  return 0 ;
}
