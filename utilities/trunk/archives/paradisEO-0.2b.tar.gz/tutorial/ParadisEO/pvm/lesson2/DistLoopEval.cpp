#include <paradiseo.h>
#include <ga.h>

typedef eoBit <double> Indi ;

#define VEC_SIZE 8
#define POP_SIZE 10000

int main (int _argc, char * * _argv) {
  
  // Communicator
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;
  
  // Channels of communication
  eoPopChan <Indi> popChan ;
  eoFitChan <Indi> fitChan ;

  /* For initialization of
     the population */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen);
  
  // The population itself ...
  eoPop <Indi> pop (POP_SIZE, random);
  
  // For distributed evaluation of the population ...
  eoDistPopLoopEval <Indi> eval (popChan, fitChan, "Mars", 300) ;
  
  eval (pop, pop) ; // The second arg. is discarded !
  
  //  std :: cout << pop << std :: endl ;
  
  eoChan :: stopChan -> destroyAll () ;

  comm.terminate () ;
  
  return 0 ;
}
