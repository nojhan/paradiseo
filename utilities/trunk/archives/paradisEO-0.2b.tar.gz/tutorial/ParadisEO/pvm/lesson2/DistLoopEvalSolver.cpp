#include <paradiseo.h>
#include <ga.h>

typedef eoBit <double> Indi ;

#include "binary_value.h"

#define VEC_SIZE 8
#define POP_SIZE 100

int main (int _argc, char * * _argv) {

  eoEvalFuncPtr <Indi, double, const std :: vector <bool> &> eval (binary_value) ;
  
  // Communicator
  Pvm:: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  // Channels of communication
  eoPopChan <Indi> popChan  ;
  eoFitChan <Indi> fitChan ;
  
  eoLoopEvalSolver <Indi> loopEvalSolver (popChan, fitChan, eval, "Mars") ;
  
  loopEvalSolver () ; // Runs ...
  
  comm.terminate () ;

  return 0 ;
}
