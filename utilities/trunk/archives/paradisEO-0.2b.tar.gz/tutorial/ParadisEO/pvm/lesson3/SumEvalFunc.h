#ifndef SumEvalFunc_h
#define SumEvalFunc_h

#include <paradiseo.h>

/** It sums partial fitnesses, that
    were previously computed ...*/
class SumEvalFunc : public eoUF <const std :: vector <double> &, double> {
  
public :
  
  double operator () (const std :: vector <double> & part_fit) ;

} ;

#endif
