#include "SumEvalFunc.h"

double SumEvalFunc :: operator () (const std :: vector <double> & part_fit) {
  
  double fit = 0 ;
  
  for (unsigned i = 0 ; i < part_fit.size () ; i ++)
    fit += part_fit [i] ;
  
  return fit ;
}
