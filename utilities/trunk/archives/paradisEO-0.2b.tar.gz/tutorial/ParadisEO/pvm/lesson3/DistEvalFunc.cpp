#include <paradiseo.h>
#include <ga.h>

#include "SumEvalFunc.h"

typedef eoBit <double> Indi ;

#define VEC_SIZE 8
#define POP_SIZE 100

#define NUM_SOLVERS 3

int main (int _argc, char * * _argv) {
  
  // Communicator
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  // Channels of communication
  eoPopChan <Indi> popChan ;
  eoFitChan <Indi> fitChan ;

  /* For initialization of
     the population */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen);
  
  /* The population
     itself ... */
  eoPop <Indi> pop (POP_SIZE, random);

  // To merge partial fitnesses ... 
  SumEvalFunc sumEval ;
  
  std :: vector <std :: string> vectLabels (NUM_SOLVERS, "Mars0") ;
  for (unsigned i = 0 ; i < NUM_SOLVERS ; i ++)
    vectLabels [i] [4] += i ;
  
  /* For distributed evaluation
     of each individual from
     the population ... */
  eoDistPopEvalFunc <Indi> eval (popChan, fitChan, vectLabels, sumEval) ;
  
  eval (pop, pop) ; // The second arg. is discarded !
  
  std :: cout << pop << std :: endl ;
  
  eoChan :: stopChan -> destroyAll () ;

  comm.terminate () ;
  
  return 0 ;
}
