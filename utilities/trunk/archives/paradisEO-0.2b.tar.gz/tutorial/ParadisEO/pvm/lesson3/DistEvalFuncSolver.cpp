#include <paradiseo.h>
#include <ga.h>

#include "PartEvalFunc.h"

#define VEC_SIZE 8
#define POP_SIZE 100

int main (int _argc, char * * _argv) {
  
  // Communicator
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  // Channels of communication
  eoPopChan <Indi> popChan  ;
  eoFitChan <Indi> fitChan ;

  PartEvalFunc partEval ((comm.rank () - 1) / (comm.size () - 1.0),
			 comm.rank () / (comm.size () - 1.0)) ;
  
  std :: string name = "Mars0" ; 
  name [4] += comm.rank () - 1 ;

  eoLoopEvalSolver <Indi> loopEvalSolver (popChan, fitChan, partEval, name) ;
  
  loopEvalSolver () ; // Runs ...
  
  comm.terminate () ;

  return 0 ;
}
