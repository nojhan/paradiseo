#include "PartEvalFunc.h"

PartEvalFunc :: PartEvalFunc (float _ratio_from,
			      float _ratio_to) : 
  ratio_from (_ratio_from),
  ratio_to (_ratio_to) {
  
}

void PartEvalFunc :: operator () (Indi & _indi){
  /* Just the well specified
     range is considered */
  
  double part_fit = 0 ;
  for (int i = (int) (_indi.size () * ratio_from) ;
       i < (int) (_indi.size () * ratio_to) ;
       i ++)
    part_fit += _indi [i] ;
  
  _indi.fitness (part_fit) ;
}
