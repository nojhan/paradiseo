#include <paradiseo.h>
#include <ga.h>

#include "binary_value.h"

/* Size for tournament
   selection */
#define T_SIZE 3 

/* Number of bits
   in genotypes */
#define VEC_SIZE 8

/* Size of
   population */
#define POP_SIZE 100 

/* Maximum number of
   generation before STOP */
#define MAX_GEN 3000 

/* Crossover
   probability */
#define P_CROSS 0.8	

/* Mutation
   probability */
#define P_MUT 1.0	

/* Internal probability
   for bit-flip mutation */
#define P_MUT_PER_BIT 0.01	

/** How often do
    migrations occur ???*/
#define FREQ_MIG 100

typedef eoBit <double> Indi ;

/** Here we want to build two cooperative island
    evolutionary algorithms, to solve the 'OneMax'
    problem */

int main (int _argc, char * * _argv) {
  
  /* Fitness
     function */
  eoEvalFuncPtr <Indi, double, const std :: vector <bool> &> eval (binary_value) ;

  /* Initilisation of
     the TWO populations */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen) ;
  eoPop <Indi> pop1 (POP_SIZE, random), pop2 (POP_SIZE, random) ;
  
  /* ##################
     Here we define the
     first evolutionary
     algorithm
     ################## */
  
  /* Deterministic
     tournament selection */
  eoDetTournamentSelect <Indi> selectOne1 (T_SIZE) ;
  eoSelectPerc <Indi> select1 (selectOne1) ; 

  /* Generational
     replacement */
  eoGenerationalReplacement <Indi> replace1 ; 

  /* Uniform
     crossover */
  eoUBitXover <Indi> xover1 ;
  
  /* Standard bit-flip
     mutation */
  eoBitMutation <Indi>  mutation1 (P_MUT_PER_BIT) ;

  /* Operators are encapsulated into an
     eoTransform object */
  eoSGATransform <Indi> transform1 (xover1, P_CROSS, mutation1, P_MUT) ;

  /* Termination condition:
     stop after MAX_GEN generations */
  eoGenContinue <Indi> genCont1 (MAX_GEN) ;
  
  /* To express a need
     of immigration every 100 gen. */
  eoFreqGenContinue <Indi> migCont1 (100) ; 
  
  /* How to select emigrants from
     the current population ? */
  eoRandomSelect <Indi> migSelectOne1 ;
  eoSelectPerc <Indi> migSelect1 (migSelectOne1, 0.1) ;
  
  /** How to assimilate immigrants into
      the current population ? */
  eoPlusReplacement <Indi> migReplace1 ;
  
  eoParaIslandMig <Indi> continuator1 (genCont1, migCont1, migSelect1, migReplace1) ;

  eoEasyEA <Indi> gga1 (continuator1, eval, select1, transform1, replace1) ;

  /* ###################
     Here we define the
     second evolutionary
     algorithm
     ################### */
  
  /* Deterministic
     tournament selection */
  eoStochTournamentSelect <Indi> selectOne2 (0.7) ;
  eoSelectPerc <Indi> select2 (selectOne2) ; 

  /* Generational
     replacement */
  eoSSGAStochTournamentReplacement <Indi> replace2 (0.8) ; 

  /* Uniform
     crossover */
  eo1PtBitXover <Indi> xover2 ;
  
  /* Deterministic bit-flip
     mutation */
  eoDetBitFlip <Indi> mutation2 ;

  /* Operators are encapsulated into an
     eoTransform object */
  eoSGATransform <Indi> transform2 (xover2, P_CROSS, mutation2, P_MUT) ;

  /* Termination condition:
     stop after MAX_GEN generations */
  eoGenContinue <Indi> genCont2 (MAX_GEN) ;
  
  /* To express a need
     of immigration every 100 gen. */
  eoFreqGenContinue <Indi> migCont2 (150) ; 
  
  /* How to select emigrants from
     the current population ? */
  eoRandomSelect <Indi> migSelectOne2 ;
  eoSelectPerc <Indi> migSelect2 (migSelectOne2, 0.2) ; 
  
  /** How to assimilate immigrants into
      the current population ? */
  eoPlusReplacement <Indi> migReplace2 ;

  eoParaIslandMig <Indi> continuator2 (genCont2, migCont2, migSelect2, migReplace2) ;
  
  eoEasyEA <Indi> gga2 (continuator2, eval, select2, transform2, replace2) ;
  
  continuator1.bind (continuator2) ;
  continuator2.bind (continuator1) ;
  
  eoAlgoTask <Indi> task1 (gga1, pop1) ;
  eoAlgoTask <Indi> task2 (gga2, pop2) ;
  
  eoParaTasks tasks ;
  tasks.push_back (& task1) ;
  tasks.push_back (& task2) ;
  
  tasks.launch () ;

  std :: cout << "Final pop. are " << std :: endl ;
  std :: cout << pop1 << std :: endl << pop2 << std :: endl ;
    
  return 0 ;
}
