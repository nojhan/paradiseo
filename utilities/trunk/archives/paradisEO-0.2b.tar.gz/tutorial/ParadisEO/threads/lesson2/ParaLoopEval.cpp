#include <paradiseo.h>
#include <ga.h>

typedef eoBit <double> Indi ;

#include "binary_value.h"

/* Length of
   binary-strings */
#define VEC_SIZE 1000

#define POP_SIZE 100

/** Number of proc. of
    the // machine ? */
#define DEGREE 4

int main (int _argc, char * * _argv) {
  
  /* For initialization of
     the population */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen);
  
  // The population itself ...
  eoPop <Indi> pop (POP_SIZE, random);
  
  eoEvalFuncPtr <Indi, double, const std :: vector <bool> &> eval (binary_value) ;
  
  // For distributed evaluation of the population ...
  eoParaPopLoopEval <Indi> popEval (eval, DEGREE) ;
  
  popEval (pop, pop) ; // The second arg. is discarded !
  
  std :: cout << pop << std :: endl ;
    
  return 0 ;
}
