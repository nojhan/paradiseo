// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "ts_move_expl_master.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/


/* ParadisEO */
#include <debug.h>
#include <mpi/eoComm.h>
#include <eoDistTSMoveExpl.h>

/* MO */
#include <eoBestImprSelect.h>
#include <eoTS.h>
#include <eoGenSolContinue.h>

/* TSP */
#include <share/graph.h>
#include <share/route.h>
#include <share/route_eval.h>
#include <share/route_init.h>
#include <share/two_opt.h>
#include <share/two_opt_init.h>
#include <share/two_opt_next.h>
#include <share/two_opt_incr_eval.h>

int main (int __argc, char * __argv []) {
  
  if (__argc != 2) {
    
    std :: cerr << "Usage : ./ts_move_expl_master [instance]" << std :: endl ;
    return 1 ;
  }

  Graph :: load (__argv [1]) ; /* Instance */

  Route route ; /* Solution */
  
  RouteInit init ; /* Sol. Random Init. */
  
  init (route) ; /* Init. the given route */

  RouteEval full_eval ; /* Full Evaluator */
  
  full_eval (route) ; /* First evaluation */

  /* Dealing with migrations */

  setVerbose () ; /* What's happening ? */
  
  Mpi :: eoComm comm (& __argc, & __argv) ; /* Using the MPI communication library */
  
  eoChan :: use (comm) ;
  
  eoNamingChan naming_chan ; /* This channel should be always instantiated */
  
  eoMoveChan <TwoOpt> move_chan ; /* To send/receive moves */

  eoEOChan <Route> route_chan ; /* send/receive routes */
  
  eoFitChan <Route> fit_chan ; /* send/receive computed fitnesses */

  eoSchedulingChan sched_chan (naming_chan) ; /* Managing the distribution of 'tasks' */
  
  eoStopChan stop_chan (naming_chan) ; /* Stopping channel */
  
  eoGenSolContinue <Route> cont (100) ; /* Generational continuator */

  std :: vector <std :: string> labels ;
  
  /* Initializing the labels of parallel
     explorers of the neighborhood */  

  for (int i = 1 ; i < comm.size () ; i ++) {
    
    std :: string label = "TwoOptExplorer " ;
    label [14] = i + '0' ;
    labels.push_back (label) ;
  }
  
  /* A managerf of parallel explorers
     of the neighborhood */
  eoDistTSMoveExpl <TwoOpt> move_expl (naming_chan, sched_chan, move_chan, route_chan, fit_chan, labels) ;
  
  eoTS <TwoOpt> ts (move_expl, cont, full_eval) ; /* A Parallel tabu search */
  
  std :: cout << "[From] " << route << std :: endl ; /* The initial route and its associated
							fitness */

  ts (route) ; /* Go ! */

  std :: cout << "[To] " << route << std :: endl ; /* The best computed route */

  /* Stoping the distributed workers */
  for (int i = 1 ; i < comm.size () ; i ++) {
    
    std :: string label = "TwoOptExplorer " ;
    label [14] = i + '0' ;
    stop_chan.terminate (label) ;
  }  
  
  stop_chan.terminate () ;

  return 0 ;
}

