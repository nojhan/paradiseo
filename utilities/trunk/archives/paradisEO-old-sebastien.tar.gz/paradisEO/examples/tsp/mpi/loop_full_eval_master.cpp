// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "loop_full_eval_master.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/


/* ParadisEO */
#include <debug.h>
#include <eoDistPopLoopEval.h>
#include <mpi/eoComm.h>

/* TSP */
#include <share/graph.h>
#include <share/route.h>
#include <share/route_init.h>

int main (int __argc, char * __argv []) {
  
  if (__argc != 2) {
    
    std :: cerr << "Usage : ./loop_full_eval_master [instance]" << std :: endl ;
    return 1 ;
  }

  Graph :: load (__argv [1]) ; /* Instance */

  RouteInit init ; /* Sol. Random Init. */
   
  eoPop <Route> pop (10, init) ; /* The evolving Population */
  
  /* Dealing with migrations */

  setVerbose () ; /* What's happening ? */
  
  Mpi :: eoComm comm (& __argc, & __argv) ; /* Using the MPI communication library */
  
  eoChan :: use (comm) ;
  
  eoNamingChan naming_chan ; /* This channel should be always instantiated */
    
  eoPopChan <Route> pop_chan ; /* Useful to send individuals to evaluating nodes */
  
  eoFitChan <Route> fit_chan ; /* Useful to receive fitnesses from evaluating nodes */

  eoSchedulingChan sched_chan (naming_chan) ; /* Managing the distribution of 'tasks' */
  
  eoStopChan stop_chan (naming_chan) ; /* Stopping channel */

  eoDistPopLoopEval <Route> pop_loop_eval (naming_chan, sched_chan, pop_chan, fit_chan, "RouteEvaluator") ;
  
  pop_loop_eval (pop, pop) ; /* Go ! */
  
  /* This is the end ! */

  stop_chan.terminate ("RouteEvaluator") ;
  
  stop_chan.terminate () ;
  
  std :: cout << pop << std :: endl ;
    
  return 0 ;
}

