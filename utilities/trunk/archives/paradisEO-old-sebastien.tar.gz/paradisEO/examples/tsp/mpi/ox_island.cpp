// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "ox_island.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

/* EO */
#include <eoEasyEA.h>
#include <eoGenContinue.h>
#include <eoStochTournamentSelect.h>
#include <eoSGATransform.h>
#include <eoSelectNumber.h>
#include <eoRandomSelect.h>
#include <utils/eoCheckPoint.h>

/* ParadisEO */
#include <eoDistAsyncIslandMig.h>
#include <eoDistSyncIslandMig.h>
#include <eoFreqContinue.h>
#include <eoRingTopology.h>
#include <debug.h>
#include <mpi/eoComm.h>
#include <eoStopChan.h>

/* TSP */
#include <share/graph.h>
#include <share/route.h>
#include <share/route_init.h>
#include <share/route_eval.h>
#include <share/order_xover.h>
#include <share/city_swap.h>

int main (int __argc, char * __argv []) {
  
  if (__argc != 2) {
    
    std :: cerr << "Usage : ./ox_island [instance]" << std :: endl ;
    return 1 ;
  }

  Graph :: load (__argv [1]) ; /* Instance */

  RouteInit init ; /* Sol. Random Init. */

  RouteEval full_eval ; /* Full Evaluator */
   
  eoPop <Route> pop (100, init) ; /* The evolving Population */
  
  eoGenContinue <Route> cont (300) ; /* Continuator (A fixed number of iterations */
  
  eoStochTournamentSelect <Route> select_one ; /* Stochastic tournament selector */

  eoSelectNumber <Route> select (select_one, 100) ; /* Selector */

  OrderXover cross ; /* Order Crossover */

  CitySwap mut ; /* City Swap Mutator */
  
  eoSGATransform <Route> transform (cross, 1, mut, 0.01) ; 
  
  eoElitism <Route> merge (1) ; /* Use of Elistism */
  
  eoStochTournamentTruncate <Route> reduce (0.7) ; /* Stoch. Replacement */
  
  eoCheckPoint <Route> checkpoint (cont) ; /* Some things to do after every
					      generation */

  /* Dealing with migrations */

  setVerbose () ; /* What's happening ? */
  
  Mpi :: eoComm comm (& __argc, & __argv) ; /* Using the MPI communication library */
  
  eoChan :: use (comm) ;
  
  eoNamingChan naming_chan ; /* This channel should be always instantiated */

  naming_chan.publish ("anything ! :-)") ; /* This is a label that will be known
					      by everyone in the distributed
					      application */
  
  eoPopChan <Route> pop_chan ; /* Useful since migrations (i.e. exchanges of individuals)
				  will be performed */
  
  eoStopChan stop_chan (naming_chan) ; /* To quit properly :-) */

  eoFreqContinue <Route> mig_cont (10) ; /* Migrations will occur periodically */
  
  eoRandomSelect <Route> mig_select_one ; /* Migrations are made of random individuals */ 
  
  eoSelectNumber <Route> mig_select (mig_select_one, 10) ; /* Selector */
 
  eoPlusReplacement <Route> mig_replace ; /* Migrations are merged with the population.
					     Then, worse individuals are discarded */
  
  eoRingTopology topo (naming_chan) ; /* The ring topology */
  
  /* eoDistAsyncIslandMig <Route> island_mig (naming_chan, pop_chan, mig_cont, mig_select, mig_replace, topo) ;*/
  
  eoDistSyncIslandMig <Route> island_mig (naming_chan, pop_chan, 10, mig_select, mig_replace, topo) ; /* OK. We're now able to build such a component */

  checkpoint.add (island_mig) ; /* To be 'activated' at the end of every gen. */ 
  
  /* We can now instantiate a full E.A. */
  eoEasyEA <Route> ea (checkpoint, full_eval, select, transform, merge, reduce) ;
  
  ea (pop) ; /* Go ! */

  std :: cout << "The best computed route is " << pop.best_element () << std :: endl ;

  naming_chan.publish ("?") ; /* Since there's nothing to do */
  
  stop_chan.terminate ("anything ! :-)") ;

  stop_chan.terminate () ;
      
  return 0 ;
}

