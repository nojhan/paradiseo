// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "ts_move_expl_solver.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/


/* ParadisEO */
#include <debug.h>
#include <eoDistTSMoveExplSolver.h>
#include <mpi/eoComm.h>

/* MO */
#include <eoItRandNextMove.h>
#include <eoNoAspirCrit.h>

/* TSP */
#include <share/graph.h>
#include <share/route.h>
#include <share/route_eval.h>
#include <share/route_init.h>
#include <share/two_opt.h>
#include <share/two_opt_init.h>
#include <share/two_opt_incr_eval.h>
#include <share/two_opt_tabu_list.h>
#include <share/two_opt_rand.h>

int main (int __argc, char * __argv []) {
  
  if (__argc != 2) {
    
    std :: cerr << "Usage : ./ts_move_expl_solver [instance]" << std :: endl ;
    return 1 ;
  }

  Graph :: load (__argv [1]) ; /* Instance */

  RouteEval full_eval ; /* Full Evaluator */
    
  /* Dealing with migrations */

  setVerbose () ; /* What's happening ? */
  
  Mpi :: eoComm comm (& __argc, & __argv) ; /* Using the MPI communication library */
  
  eoChan :: use (comm) ;
  
  eoNamingChan naming_chan ; /* This channel should be always instantiated */
  
  eoMoveChan <TwoOpt> move_chan ; /* To send/receive moves */

  eoEOChan <Route> route_chan ; /* send/receive routes */
  
  eoFitChan <Route> fit_chan ; /* send/receive computed fitnesses */

  eoSchedulingChan sched_chan (naming_chan) ; /* Managing the distribution of 'tasks' */
  
  eoStopChan stop_chan (naming_chan) ; /* Stopping channel */
  
  TwoOptInit two_opt_init ; /* Move Init. */
  
  TwoOptRand two_opt_rand ; /* Generator of random moves */
    
  /* We don't distribute the full neighborhood. Instead, we
     consider an iterative random explorer
     of 100 neighbors */
  eoItRandNextMove <TwoOpt> two_opt_next (two_opt_rand, 100) ;
  
  TwoOptIncrEval two_opt_incr_eval ; /* For efficient evaluation */
 
  TwoOptTabuList tabu_list ; /* Tabu List */

  eoNoAspirCrit <TwoOpt> aspir_crit ; /* Aspiration Criterion */ 
  
  /* Setting the label of this worker */
  std :: string label = "TwoOptExplorer " ;
  label [14] = comm.rank () + '0' ;
  
  /* OK */
  eoDistTSMoveExplSolver <TwoOpt> solver (naming_chan, sched_chan, stop_chan, move_chan, route_chan, fit_chan, two_opt_init, two_opt_next, two_opt_incr_eval, tabu_list, aspir_crit, label) ;
  
  /* In order the distributed workers behave differently */
  rng.reseed (comm.rank ()) ;

  solver () ; /* Go ! */

  /* This is the end ! */
  
  stop_chan.terminate () ;

  return 0 ;
}

