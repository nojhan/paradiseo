#include <eo>
#include <pvm/eoComm.h>
#include <eoDistPopEvalFunc.h>
#include <eoStopChan.h>
#include <ga.h>
#include <debug.h>

#include "SumEvalFunc.h"

typedef eoBit <double> Indi ;

#define VEC_SIZE 8
#define POP_SIZE 10

#define NUM_SOLVERS 3

int main (int _argc, char * * _argv) {
  
  setVerbose () ;

  /* Unsinf the PVM communication library */
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  /* Channels of communication */
  eoNamingChan namingChan ; /* Naming */
  eoSchedulingChan schedChan (namingChan) ; /* Scheduling */
  eoPopChan <Indi> popChan ; /* Population */
  eoFitChan <Indi> fitChan ; /* Fitness */
  eoStopChan stopChan (namingChan) ; /* Stopping channel */

  /* For initialization of the population */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen);
  
  /* The population
     itself ... */
  eoPop <Indi> pop (POP_SIZE, random);

  // To merge partial fitnesses ... 
  SumEvalFunc sumEval ;
  
  std :: vector <std :: string> vectLabels (NUM_SOLVERS, "Evaluator0") ;
  
  for (unsigned i = 0 ; i < NUM_SOLVERS ; i ++)
    vectLabels [i] [9] += i ;
  
  /* For distributed evaluation of each individual from the population ... */
  eoDistPopEvalFunc <Indi> eval (namingChan, schedChan, popChan, fitChan, vectLabels, sumEval) ;
  
  eval (pop, pop) ; // The second arg. is discarded !
  
  std :: cout << pop << std :: endl ;
  
  std :: string label = "Evaluator0" ;
  
  for (unsigned i = 0 ; i < NUM_SOLVERS ; i ++) {
    label [9] = i ;
    stopChan.terminate (label) ;
  }
  
  stopChan.terminate () ;
  
  return 0 ;
}
