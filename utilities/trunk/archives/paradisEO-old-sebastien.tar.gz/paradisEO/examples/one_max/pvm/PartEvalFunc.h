/* -*- c++ -*- */

#ifndef PartEvalFunc_h
#define PartEvalFunc_h

#include <eo>
#include <ga.h>

typedef eoBit <double> Indi ;

/** This partial evaluator sums the number
    of '1' in a given string
    for a delimited range ... */
class PartEvalFunc : public eoEvalFunc <Indi> {
  
public :
  
  /* Constructor */
  PartEvalFunc (float _ratio_from, float _ratio_to) ;
  
  /* For a given bit-string ... */
  void operator () (Indi & _indi) ;

private :
  
  float ratio_from, ratio_to ;
  
} ;

#endif
