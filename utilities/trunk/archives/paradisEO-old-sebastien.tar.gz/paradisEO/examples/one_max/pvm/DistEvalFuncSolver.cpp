#include <eo>
#include <pvm/eoComm.h>
#include <eoDistPopLoopSolver.h>
#include <eoStopChan.h>
#include <ga.h>
#include <debug.h>
#include "PartEvalFunc.h"

#define VEC_SIZE 8
#define POP_SIZE 100

int main (int _argc, char * * _argv) {

  setVerbose () ;

  /* Using the PVM communication library */
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  /* Channels of communication */
  eoNamingChan namingChan ; /* Naming */
  eoSchedulingChan schedChan (namingChan) ; /* Scheduling */
  eoPopChan <Indi> popChan ; /* Population */
  eoFitChan <Indi> fitChan ; /* Fitness */
  eoStopChan stopChan (namingChan) ; /* Stopping channel */
  
  PartEvalFunc partEval ((comm.rank () - 1) / (comm.size () - 1.0), comm.rank () / (comm.size () - 1.0)) ;
  
  std :: string name = "Evaluator0" ; 
  name [9] += comm.rank () - 1 ;
  
  /* Solver */
  eoDistPopLoopSolver <Indi> pop_loop_solver (namingChan, schedChan, stopChan, popChan, fitChan, partEval, name) ;

  pop_loop_solver () ; /* Go ! */

  stopChan.terminate () ;

  return 0 ;
}
