/* -*- c++ -*- */

#ifndef SumEvalFunc_h
#define SumEvalFunc_h

#include <ga.h>
#include <eoAggEvalFunc.h>

typedef eoBit <double> Indi ;

/** It sums partial fitnesses, that were previously computed ...*/
class SumEvalFunc : public eoAggEvalFunc <Indi> {
  
public :
  
  void operator () (Indi & __indi, const std :: vector <double> & __part_fit) ;
  
} ;

#endif
