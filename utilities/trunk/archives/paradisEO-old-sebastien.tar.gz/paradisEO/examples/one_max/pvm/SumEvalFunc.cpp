#include "SumEvalFunc.h"

void SumEvalFunc :: operator () (Indi & __indi, const std :: vector <double> & __part_fit) {
  
  double fit = 0 ;
  
  for (unsigned i = 0 ; i < __part_fit.size () ; i ++)
    fit += __part_fit [i] ;
  __indi.fitness (fit) ;
}

