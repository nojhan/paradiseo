#include <eo>
#include <pvm/eoComm.h>
#include <eoDistPopLoopEval.h>
#include <ga.h>
#include <debug.h>

typedef eoBit <double> Indi ;

#define VEC_SIZE 8
#define POP_SIZE 10000

int main (int _argc, char * * _argv) {
  
  setVerbose () ;

  /* Communicator */
  Pvm :: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;
   
  /* Channels of communication */
  eoNamingChan namingChan ; /* Naming */
  eoSchedulingChan schedChan (namingChan) ; /* Scheduling */
  eoPopChan <Indi> popChan ; /* Population */
  eoFitChan <Indi> fitChan ; /* Fitness */
  eoStopChan stopChan (namingChan) ; /* Stopping channel */

  /* For initialization of the population */
  eoUniformGenerator <bool> uGen ;
  eoInitFixedLength <Indi> random (VEC_SIZE, uGen);
  
  /* The population itself ... */
  eoPop <Indi> pop (POP_SIZE, random);
  
  /* For distributed evaluation of the population ... */
  eoDistPopLoopEval <Indi> eval (namingChan, schedChan, popChan, fitChan, "Evaluator") ;
  
  eval (pop, pop) ; // The second arg. is discarded !
  
  std :: cout << pop << std :: endl ;
  
  stopChan.terminate ("Evaluator") ;
  
  stopChan.terminate () ;
  
  return 0 ;
}
