#include <eo>
#include <eoDistPopLoopSolver.h>
#include <pvm/eoComm.h>
#include <ga.h>

typedef eoBit <double> Indi ;

#include "binary_value.h"

#define VEC_SIZE 8
#define POP_SIZE 100

int main (int _argc, char * * _argv) {

  eoEvalFuncPtr <Indi, double, const std :: vector <bool> &> eval (binary_value) ;
  
  setVerbose () ;

  /* Communicator */
  Pvm:: eoComm comm (_argc, _argv) ;
  eoChan :: use (comm) ;

  /* Channels of communication */
  eoNamingChan namingChan ; /* This channel should be always instantiated */
  eoSchedulingChan schedChan (namingChan) ; /* Managing the distribution of 'tasks' */
  eoPopChan <Indi> popChan ; /* Useful to receive individuals to evaluate */  
  eoFitChan <Indi> fitChan ; /* Useful to send computed fitnesses ! */  
  eoStopChan stopChan (namingChan) ; /* Stopping channel */
  
  /* Solver */
  eoDistPopLoopSolver <Indi> pop_loop_solver (namingChan, schedChan, stopChan, popChan, fitChan, eval, "Evaluator") ;

  pop_loop_solver () ; /* Go ! */
  
  /* This is the end ! */
  stopChan.terminate () ;

  return 0 ;
}
