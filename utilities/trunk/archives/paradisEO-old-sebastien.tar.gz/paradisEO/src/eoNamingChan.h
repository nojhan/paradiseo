// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoNamingChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoNamingChan_h
#define eoNamingChan_h

#include <vector>
#include <string>

#include "eoChan.h"

/** */
class eoNamingChan : public eoChan, public std :: vector <std :: string> {
  
public :
  
  /** Constructor */
  eoNamingChan () ;

  /** Destructor */
  virtual ~ eoNamingChan () ;

  /** Initialization */
  void init () ;

  /** It publishes the given label to every distributed node
      in the community */
  void publish (const std :: string & __label) ;
  
  /** It waits for a given number of nodes have published
      the following label */
  void wait (const std :: string & __label, unsigned __atLeast = 1) ;
  
  /** Updating the arrival of incoming notifications */
  bool update () ;
  
  void sync () ;

} ;

#endif
