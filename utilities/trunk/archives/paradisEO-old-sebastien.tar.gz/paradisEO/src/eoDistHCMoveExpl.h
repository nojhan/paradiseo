// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistHCMoveExpl.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistHCMoveExpl_h
#define eoDistHCMoveExpl_h

#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoEOChan.h"
#include "eoFitChan.h"
#include "eoStopChan.h"
#include "eoDistMoveExpl.h"
#include "eoMoveChan.h"
#include "debug.h"

#include <eoMoveSelect.h>

template <class M> class eoDistHCMoveExpl : public eoDistMoveExpl <M> {

  /* Alias */
  typedef typename M :: EOType EOT ;

  typedef typename M :: EOType :: Fitness Fitness ; 
  
public :
  
  /** Constructor */
  eoDistHCMoveExpl (eoNamingChan & __namingChan,
		    eoSchedulingChan & __schedChan,
		    eoMoveChan <M> & __moveChan,
		    eoEOChan <EOT> & __EOChan,
		    eoFitChan <EOT> & __fitChan,
		    eoMoveSelect <M> & __moveSelect,
		    const std :: vector <std :: string> & __labels
		    ) : 
    namingChan (__namingChan),
    schedChan (__schedChan),
    moveChan (__moveChan),
    EOChan (__EOChan),
    fitChan (__fitChan),
    moveSelect (__moveSelect),
    labels (__labels) {
    
  }

  void operator () (const EOT & __old_sol, EOT & __new_sol) {
    
    moveSelect.init (__old_sol.fitness ()) ;

    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "sending the current solution for parallel exploration of the neighborhood" << std :: endl ;   
    }
    
    /* Sending initial solutions
       to parallel explorers */
    for (unsigned i = 0 ; i < labels.size () ; i ++) {
      
      unsigned rk = schedChan.wait (labels [i]) ;
      
      EOChan.send (rk, __old_sol) ;       
    }
    
    /* Receiving the solutions an associated
       movements selected from the
       local neighborhood */
    unsigned n = 0 ;
    
    while (n < labels.size ()) {
      
      fitChan.wait () ;

      for (unsigned i = 0 ; i < fitChan.size () ; i ++)
	if (! fitChan [i].empty ()) {
	  
	  Fitness & loc_best_fit = fitChan [i].front ().front () ;
	  	  
	  if (loc_best_fit != 0) {

	    while (moveChan [i].empty ())
	      moveChan.wait () ;
	  
	    if (verbose ()) {
	      displayDateAndLocation () ;
	      std :: cout << "receiving a solution from one of the partial explorers" << std :: endl ;   
	    }
	    
	    M & loc_best_move = moveChan [i].front () ;
	    
	    moveSelect.update (loc_best_move, loc_best_fit) ;
	    
	    moveChan [i].pop () ;
	  }
	  fitChan [i].pop () ;
	
	  n ++ ;  
	}
    }
    
    M best_move ;
    Fitness best_fit ;

    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "selecting the best solution among those received from partial explorers" << std :: endl ;   
    }
        
    moveSelect (best_move, best_fit) ;

    __new_sol.fitness (best_fit) ;
    
    best_move (__new_sol) ;
  
  }
  
private :

  eoNamingChan & namingChan ; /* Channel for namming */
  
  eoSchedulingChan & schedChan ; /* Scheduling channel */
		    
  eoMoveChan <M> & moveChan ; /* Channel for 'movements' */
  
  eoEOChan <EOT> & EOChan ; /* Channel for Evolving Objects */
  
  eoFitChan <EOT> & fitChan ; /* Channel for fitnesses */

  eoMoveSelect <M> & moveSelect ; /* Selector of local best movements */
  
  const std :: vector <std :: string> & labels ; /* Labels of parallel
						    explorers of the
						    neighborhood */

} ;

#endif
