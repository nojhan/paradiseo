// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoPersistentChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoPersistentChan_h
#define eoPersistentChan_h

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

#include <eoPersistent.h>

#include "eoSerialChan.h"

/** This class allows the exchange of persistent objects
    in the sens of EO, meaning 'printOn' and 'readFrom' are
    meaningful for T */
template <class T> class eoPersistentChan : public eoSerialChan <T> {

public :
  
  /** Constructor */
  eoPersistentChan (std :: string __className
		    ) : eoSerialChan <T> (__className) { 
  }
  
private :
  
  /** Stores a T instance to a string object */
  void serialize (const T & __t, std :: string & __str) {
    
#ifdef HAVE_SSTREAM
    std :: ostringstream os ;
#else
    std :: ostrstream os ;
#endif

    __t.printOn (os) ;
    os << '\0' ;
    __str = os.str () ;
  }
  
  /** Creates a T object from a stored representation */
  void unserialize (T & __t, const std :: string & __str) {
    
#ifdef HAVE_SSTREAM    
    std :: istringstream is (__str.c_str ()) ;
#else
    std :: istrstream is (__str.c_str ()) ;
#endif

    __t.readFrom (is) ;
  } 
  
} ;

#endif
 
