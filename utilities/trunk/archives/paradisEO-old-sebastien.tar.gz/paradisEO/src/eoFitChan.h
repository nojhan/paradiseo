// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoFitChan.h"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoFitChan_h
#define eoFitChan_h

#include <eoPop.h>

#include "eoSerialChan.h"

template <class EOT> class eoFitChan : public eoSerialChan <std :: vector <typename EOT :: Fitness> > {
  
  // Nothing ! Just an alias :-)
  
public :

  typedef typename EOT :: Fitness Fit ;
  
  /** Constructor */
  eoFitChan (std :: string __className = ""
	     ) : eoSerialChan <std :: vector <Fit> > ("eo" + __className + "FitChan") {
    
    if (comm)
      init () ;
    else
      awaiting_channels.push_back (this) ;
  }

private :
  
  /** Stores a T instance to a string object */
  void serialize (const std :: vector <Fit> & __vectFit, std :: string & __str) {
    
#ifdef HAVE_SSTREAM
    std :: ostringstream os ;
#else
    std :: ostrstream os ;
#endif
    
    os << __vectFit.size () << ' ' ;
    for (unsigned i = 0 ; i < __vectFit.size () ; i ++)
      os << __vectFit [i] << ' ' ;
    os << '\0' ;
    __str = os.str () ;
  }
  
  /** Creates a T object from a stored representation */
  void unserialize (std :: vector <Fit> & __vectFit, const std :: string & __str) {
    
#ifdef HAVE_SSTREAM    
    std :: istringstream is (__str.c_str ()) ;
#else
    std :: istrstream is (__str.c_str ()) ;
#endif

    unsigned sz ;
    is >> sz ;
    __vectFit.resize (sz) ;
    for (unsigned i = 0 ; i < sz ; i ++)
      is >> __vectFit [i] ;
  } 
  
} ;

#endif
