// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistAsyncEA.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistAsyncEA_h
#define eoDistAsyncEA_h

#include <eoAlgo.h>

#include <eoContinue.h>
#include <eoSelectOne.h>
#include <eoSGATransform.h>

#include <paradisEO/eoNamingChan.h>
#include <paradisEO/eoEOChan.h>
#include <paradisEO/eoSchedulingChan.h>
#include <paradisEO/debug.h>

/** The asynchreonous Evolutionary Algorithm.
    Here, the process is not blocking until
    all individuals that were distributed for
    distribution are coming back */
template <class EOT> class eoDistAsyncEA : public eoAlgo <EOT> {

public :
  
  /** Constructor */
  eoDistAsyncEA (eoNamingChan & __namChan,
		 eoSchedulingChan & __schedChan,
		 eoEOChan <EOT> & __EOChan,
		 eoContinue <EOT> & __cont,		 
		 eoSelectOne <EOT> & __selectOne,
		 eoSGATransform <EOT> & __sgaTransform,
		 eoSelectOne <EOT> & __replace,
		 const std :: string & __label,
		 unsigned __stackSize
		 ) : namChan (__namChan),
		     schedChan (__schedChan),
		     EOChan (__EOChan),
    		     cont (__cont),
		     selectOne (__selectOne),
		     sgaTransform (__sgaTransform),		     
		     replace (__replace),
		     label (__label),
		     stackSize (__stackSize) {
    
  }
  
  /** For a given population */
  void operator () (eoPop <EOT> & __pop) {

    if (debug :: verbose ()) {
      
      debug :: displayDateAndLocation () ;
      * debug :: os << "performing the first evaluation of the population" << std :: endl ;   
    }
    
    // First evalution
    for (unsigned i = 0 ; i < __pop.size () ; i ++) {
	  
      unsigned rk = _schedChan.wait (_label) ;      
      _EOChan.send (rk, __pop [i]) ;      
    }
    
    unsigned old_size = __pop.size () ;

    __pop.clear () ;
    
    while (__pop.size () < old_size) {
      
      _EOChan.wait () ;
      for (unsigned i = 0 ; i < _EOChan.size () ; i ++)
	if (_namChan [i] == _label)
	  while (! _EOChan [i].empty ()) {
	    
	    __pop.push_back (_EOChan [i].front ()) ;
	    _EOChan [i].pop () ;
	  }
    }

    _firstTime = true ;
    
    // Go !
    do {
      
      unsigned _num ;

      if (_firstTime) {
	
	_num = _stackSize ;
	_firstTime = false ;
      }
      else
	_num = 1 ;
      
      for (unsigned i = 0 ; i < _num ; i ++) {

	if (debug :: verbose ()) {
	  
	  debug :: displayDateAndLocation () ;
	  * debug :: os << "performing the selection" << std :: endl ;   
	}
		
	// Selection
	_selectOne.setup (__pop) ;
	
	eoPop <EOT> _par ;
	
	_par.push_back (_selectOne (__pop)) ;
	_par.push_back (_selectOne (__pop)) ;


	if (debug :: verbose ()) {
	  
	  debug :: displayDateAndLocation () ;
	  * debug :: os << "performing the variation" << std :: endl ;   
	}
		
	// Breeding
	_sgaTransform (_par) ;
	
	// Evaluation ?
	
	// First child ...
 	unsigned rk = _schedChan.wait (_label) ;      
	_EOChan.send (rk, _par [0]) ;
	
	// ... and the other
	rk = _schedChan.wait (_label) ;
		
	_EOChan.send (rk, _par [1]) ;
	
      }
      
      // Replacement of old ones ?
      
      bool _something = false ;
      
      do {
	
	_EOChan.wait () ;
	for (unsigned i = 0 ; i < _EOChan.size () ; i ++)
	  if (_namChan [i] == _label && ! _EOChan [i].empty ())
	    _something = true ;
	
      } while (! _something) ;
      
      for (unsigned i = 0 ; i < _EOChan.size () ; i ++)
	if (_namChan [i] == _label)
	  while (! _EOChan [i].empty ()) {
	    
	    if (debug :: verbose ()) {
	      
	      debug :: displayDateAndLocation () ;
	      * debug :: os << "performing the replacement" << std :: endl ;   
	    }
	    
	    _replace.setup (__pop) ;
	    
	    EOT & bad = const_cast <EOT &> (_replace (__pop)) ; 
	    bad = _EOChan [i].front () ;
	    _EOChan [i].pop () ;
	    
	    if (! _cont (__pop)) {
	      return ;
	    }	    
	  }
      
    } while (true) ; 
  }

private :

  bool _firstTime ;

  eoNamingChan & _namChan ; // Naming channel
  
  eoSchedulingChan & _schedChan ; // Scheduling channel
  
  eoEOChan <EOT> & _EOChan ; // EO Channel
  
  eoContinue <EOT> & _cont ; // Continuator
  
  eoSelectOne <EOT> & _selectOne ; // Selector
  
  eoSGATransform <EOT> & _sgaTransform ; // Accepting quadratic crossover & unary mutation
  
  eoSelectOne <EOT> & _replace ; // Selector & replacator :-)
  
  std :: string _label ; // Label of the worker nodes

  unsigned _stackSize ;
} ;

#endif
