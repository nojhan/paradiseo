// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistTSMoveExpl.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistTSMoveExpl_h
#define eoDistTSMoveExpl_h

#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoEOChan.h"
#include "eoFitChan.h"
#include "eoStopChan.h"
#include "debug.h"

#include "eoDistMoveExpl.h"
#include "eoMoveChan.h"

#include <eoBestImprSelect.h>

static bool ok (const std :: string & __label, const std :: vector <std :: string> & __vect_labels) {
  
  for (unsigned i = 0 ; i < __vect_labels.size () ; i ++)
    if (__vect_labels [i] == __label)
      return true ;
  
  return false ;
}

template <class M> class eoDistTSMoveExpl : public eoDistMoveExpl <M> {

  /* Alias */
  typedef typename M :: EOType EOT ;

  typedef typename M :: EOType :: Fitness Fitness ; 
  
public :
  
  /** Constructor */
  eoDistTSMoveExpl (eoNamingChan & __namingChan,
		    eoSchedulingChan & __schedChan,
		    eoMoveChan <M> & __moveChan,
		    eoEOChan <EOT> & __EOChan,
		    eoFitChan <EOT> & __fitChan,		    
		    const std :: vector <std :: string> & __labels
		    ) : 
    namingChan (__namingChan),
    schedChan (__schedChan),
    moveChan (__moveChan),
    EOChan (__EOChan),
    fitChan (__fitChan),
    labels (__labels) {
    
  }

  void operator () (const EOT & __old_sol, EOT & __new_sol) {
    
    moveSelect.init (__old_sol.fitness ()) ;

    if (verbose ()) {
	displayDateAndLocation () ;
	std :: cout << "sending the current solution for parallel exploration of the neighborhood" << std :: endl ;   
    }

    /* Sending initial solutions
       to parallel explorers */
    for (unsigned i = 0 ; i < labels.size () ; i ++) {
      
      unsigned rk = schedChan.wait (labels [i]) ;
      
      EOChan.send (rk, __old_sol) ;       
    }
    
    /* Receiving the solutions an associated
       movements selected from the
       local neighborhood */
    unsigned n = 0 ;
    
    while (n < labels.size ()) {
      
      fitChan.wait () ;

      for (unsigned i = 0 ; i < fitChan.size () ; i ++)
	if (! fitChan [i].empty ()) {
	  
	  Fitness & loc_best_fit = fitChan [i].front ().front () ;
	  	  
	  if (loc_best_fit != 0) {

	    while (moveChan [i].empty ())
	      moveChan.wait () ;
	  
	    M & loc_best_move = moveChan [i].front () ;
	    
	    moveSelect.update (loc_best_move, loc_best_fit) ;
	    
	    if (verbose ()) {
	      displayDateAndLocation () ;
	      std :: cout << "receiving a solution from one of the partial explorers" << std :: endl ;   
	    }
	    
	    moveChan [i].pop () ;
	  }
	  fitChan [i].pop () ;
	
	  n ++ ;
	}
    }
    
    M best_move ;
    Fitness best_fit ;
    
    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "selecting the best solution among those received from partial explorers" << std :: endl ;   
    }

    moveSelect (best_move, best_fit) ;

    __new_sol.fitness (best_fit) ;
    
    best_move (__new_sol) ;

    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "sending both the selected move and neighbors in order to update the distributed tabu lists" << std :: endl ;   
    }
        
    /* Sending the chosen movement to all the workers */
    for (unsigned i = 0 ; i < namingChan.size () ; i ++)
      if (ok (namingChan [i], labels)) {
	moveChan.send (i, best_move) ;
	EOChan.send (i, __new_sol) ; 
      }
  }
  
private :

  eoNamingChan & namingChan ; /* Channel for namming */
  
  eoSchedulingChan & schedChan ; /* Scheduling channel */
		    
  eoMoveChan <M> & moveChan ; /* Channel for 'movements' */
  
  eoEOChan <EOT> & EOChan ; /* Channel for Evolving Objects */
  
  eoFitChan <EOT> & fitChan ; /* Channel for fitnesses */

  eoBestImprSelect <M> moveSelect ; /* Selector of local best movements */
  
  const std :: vector <std :: string> & labels ; /* Labels of parallel
						    explorers of the
						    neighborhood */

} ;

#endif
