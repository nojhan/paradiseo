// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <pvm3.h>

#include <utils/eoParser.h>
#include "eoComm.h"

#define PVM_TAG 4321 

namespace Pvm {
    
  eoComm :: eoComm (int _argc,
		    char * _argv []
		    ) : wait_buf_ID (0) {
    
    pvm_mytid () ;
    pvm_catchout (stdout) ;        
    
    if (pvm_parent () == PvmNoParent) {
      // Master ?
      
      // Me
      tids.push_back (pvm_mytid ()) ;
      rk = 0 ;
      
      eoParser parser (_argc, _argv) ;
      
      eoValueParam <std :: string> schema_file_name ("", "schema") ;
      parser.processParam (schema_file_name) ;
    
      /* Loading
	 schema ... */
      loadSchema (schema_file_name.value ().c_str ()) ;
      
      /* Spawning
	 processes ... */
      for (unsigned i = 0 ; i < file_names.size () ; i ++) {
	
	int * local_tids = new int [degrees [i]] ;
	pvm_spawn ((char *) file_names [i].c_str (),
		   _argv + 1,
		   PvmTaskDefault,
		   0,
		   degrees [i],
		   local_tids) ; 
	
	/* Adding
	   new tids ... */
	for (int j = 0 ; j < degrees [i] ; j ++)
	  tids.push_back (local_tids [j]) ;
	delete [] local_tids ;
      }
      
      /* Sending 'tids'
	 to all slaves ... */
      
#ifdef HAVE_SSTREAM
      std :: ostringstream os ;
#else      
      std :: ostrstream os ;
#endif

      os << tids.size () - 1 << ' ' ; // How many processes ?
      for (unsigned i = 1 ; i < tids.size () ; i ++) // Master is discarded !
	os << tids [i] << ' ' ;
      
      for (unsigned i = 1 ; i < tids.size () ; i ++) 
	send (PVM_TAG, i, os) ;
    }
    else {
      
      // Slave ?
      
      tids.push_back (pvm_parent ()) ;
      
      /* Some info
	 from master ... */
      std :: string mess ;
      receive (PVM_TAG, 0, mess) ;
      
#ifdef HAVE_SSTREAM
      std :: istringstream os (mess) ;
#else
      std :: istrstream os (mess) ;
#endif

      // Size ?
      unsigned len ;
      
      os >> len ;
      tids.resize (len + 1) ;
      
      for (unsigned i = 1 ; i < len + 1 ; i ++)
	os >> tids [i] ;
      
      // Rank ?
      rk = 0 ;
      for (unsigned i = 0 ; i < tids.size () ; i ++)
	if (tids [i] == pvm_mytid ()) {
	  rk = i ;
	  break ;
	}
    }
  }
  
  eoComm :: ~ eoComm () {
    
    // Nothing !
  }

  void eoComm :: loadSchema (const char * _schema_file_name) {
    	
    std :: ifstream f (_schema_file_name) ;
    
    if (f) {
      
      int degree ;
      std :: string file_name ;

      while (! f.eof ()) {
	
	f >> file_name >> degree ;

	// OK.
	file_names.push_back (file_name) ;
	degrees.push_back (degree) ;
      }
      
      // Last shoud be discarded !
      file_names.pop_back () ;
      degrees.pop_back () ;
      
      f.close () ;
      
    }
    else       
      std :: cout << "## Can't open " << _schema_file_name << " !" << std :: endl ;
    
  }  

  void eoComm :: send (unsigned _tag,
 		       unsigned _dest,
		       const std :: string & _str) {
    
    pvm_initsend (PvmDataDefault) ;
    pvm_pkstr ((char *) _str.c_str ()) ;
    pvm_send (tids [_dest], _tag) ;
  }
    
#ifdef HAVE_SSTREAM
  void eoComm :: send (unsigned _tag,
		       unsigned _dest,
		       std :: ostringstream & _os) {
    _os << '\0' ;
    send (_tag, _dest, _os.str ()) ;
  }
#else
  void eoComm :: send (unsigned _tag,
		       unsigned _dest,
		       std :: ostrstream & _os) {
    _os << '\0' ;
    send (_tag, _dest, _os.str ()) ;
  }
#endif

  void eoComm :: receive (unsigned _tag,
			  unsigned _src,
			  std :: string & _str) {
    
    int len, trash ;
    
    // Blocking ...
    int id ;

    if (wait_buf_ID) 
      id = wait_buf_ID ;
    else
      id = pvm_recv (tids [_src], _tag) ;
    
    pvm_bufinfo (id, & len, & trash, & trash) ;
    char * buff = new char [len] ;
    
    // Unpacking ...
    pvm_upkstr (buff) ;
    _str.assign (buff) ;
    delete [] buff ;
    
    wait_buf_ID = 0 ;
  }
  
  bool eoComm :: probe (unsigned _tag,
			unsigned _src) {
   
    // Blocking ...
    if (wait_buf_ID) {
      
      int tag, tid ;
      pvm_bufinfo (wait_buf_ID, & len, & tag, & tid) ;
      
      return (unsigned) tag == _tag && tid == tids [_src] ;
    }
    else
      return  pvm_probe (tids [_src], _tag) ;
    
  }
  
  bool eoComm :: probeAnySource (unsigned _tag) {
        
    // Blocking ...
    if (wait_buf_ID) {
      
      int tag, tid ;
      pvm_bufinfo (wait_buf_ID, & len, & tag, & tid) ;
      
      return (unsigned) tag == _tag ;
    }
    else
      return pvm_probe (- 1, _tag) ;
  }

  
  bool eoComm :: probeAnyTagAnySource () {
    
    return wait_buf_ID || pvm_probe (- 1, - 1) ;
  }

  void eoComm :: waitAnyTagAnySource () {
   
    wait_buf_ID = pvm_recv (- 1, - 1) ;
  }

  int eoComm :: rank () {
    
    return rk ;
  }
  
  int eoComm :: size () {
    
    return tids.size () ;
  }
  
  void eoComm :: terminate () {

    pvm_exit () ;
  }
}

