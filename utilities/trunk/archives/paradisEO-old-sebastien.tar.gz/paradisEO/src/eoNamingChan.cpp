// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoNamingChan.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <iostream>

#include "eoNamingChan.h"
#include "debug.h"

eoNamingChan :: eoNamingChan () : eoChan ("eoNamingChan") {
  
  if (comm)
    init () ;
  else
    awaiting_channels.push_back (this) ;
}

void eoNamingChan :: init () {
  
  eoChan :: init () ;

  // Initialization (labels are first unknown)
  resize (comm -> size (), "?") ;
}

eoNamingChan :: ~ eoNamingChan () {
  
  // Nothing ! :-)
}

void eoNamingChan :: publish (const std :: string & __label) {

  if (verbose ()) {
    displayDateAndLocation () ;
    std :: cout << "publishing " << __label << std :: endl ;   
  }
  
  for (int i = 0 ; i < comm -> size () ; i ++)
    if (i != comm -> rank ())
      comm -> send (tag, i, __label) ;
    else
      operator [] (i) = __label ;
}

void eoNamingChan :: wait (const std :: string & __label, unsigned __atLeast) {
  
  updateAll () ;
 
  bool first_time = true ; 
  
  unsigned count = 0 ;

  while (count < __atLeast) {
      
    if (! first_time) {
      
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    }
    else
      first_time = false ;
    
    count = 0 ;
    for (unsigned i = 0 ; i < size () ; i ++)
      if (operator [] (i) == __label)
	count ++ ;
  }
}
/*
void eoNamingChan :: sync () {
  
  wait ("?", size ()) ;
}
*/

bool eoNamingChan :: update () {
  
  bool r = false ;

  while (comm -> probeAnySource (tag)) {
    
    for (unsigned i = 0 ; i < size () ; i ++)
      if (comm -> probe (tag, i)) {
	
	r = true ;
       
	comm -> receive (tag, i, operator [] (i)) ; 	
      }
  }

  return r ;
}

void eoNamingChan :: sync () {
  
  bool ok = false ;
  
  if (verbose ()) {
    displayDateAndLocation () ;
    std :: cout << "requesting synchronization" << std :: endl ;   
  }
  
  while (! ok) {
    
    ok = true ;
    
    for (unsigned i = 0 ; i < size () ; i ++)
      if (operator [] (i) == "?") {
	ok = false ;
	break ;
      }
    
    if (! ok) {
           
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    }
  }
  
  if (verbose ()) {
    displayDateAndLocation () ;
    std :: cout << "reached synchronization" << std :: endl ;   
  }
}
