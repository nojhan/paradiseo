// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoMpiComm_h
#define eoMpiComm_h

#include "../eoComm.h"

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

/** For the Message Passing Interface (MPI) */

namespace Mpi {
  
  class eoComm : public :: eoComm {
    
  public :
      
    eoComm (int * __argc,
	    char * * __argv []) ;
    
    void send (unsigned __tag,
	       unsigned __dest,
	       const std :: string & __str) ;
    
#ifdef HAVE_SSTREAM
    void send (unsigned __tag,
	       unsigned __dest,
	       std :: ostringstream & __os) ;
#else
    void send (unsigned __tag,
	       unsigned __dest,
	       std :: ostrstream & __os) ;
#endif
    
    void receive (unsigned __tag,
		  unsigned __src,
		  std :: string & __str) ;
    
    bool probe (unsigned __tag,
		unsigned __src) ;
    
    bool probeAnySource (unsigned __tag) ;    
    
    bool probeAnyTagAnySource () ;
    
    void waitAnyTagAnySource () ;
    
    int rank () ;
    
    int size () ; 
      
    void terminate () ;
    
    private :
    
    int len, rk ; // Size & Rank
  
  } ;
}

#endif
