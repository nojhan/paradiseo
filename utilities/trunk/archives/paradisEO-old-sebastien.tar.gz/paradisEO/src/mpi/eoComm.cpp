// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoComm.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "eoComm.h"

#include <vector> 

#include <mpi.h>

namespace Mpi {

  static std :: vector <char *> vect_mess ;
    
  static std :: vector <MPI_Request *> vect_req ;

  static void cleanBuffers () {
    
    for (unsigned i = 0 ; i < vect_req.size () ; i ++) {
      
      MPI_Status stat ;
      int flag ;
      MPI_Test (vect_req [i], & flag, & stat) ;
      if (flag) {
	
	delete vect_mess [i] ;
	delete vect_req [i] ;
	
	vect_mess [i] = vect_mess.back () ;
	vect_mess.pop_back () ;

	vect_req [i] = vect_req.back () ;
	vect_req.pop_back () ;
      }	
    }
  }
    
  eoComm :: eoComm (int * __argc,
		    char * * __argv []) {
    
    MPI_Init (__argc, __argv) ; // To be done once :-)     
    MPI_Comm_size (MPI_COMM_WORLD, & len) ; // How many ?
    MPI_Comm_rank (MPI_COMM_WORLD, & rk) ; // Who am I ?
  }
  
  void eoComm :: send (unsigned __tag,
		       unsigned __dest,
		       const std :: string & __str) {
    
    cleanBuffers () ;

    MPI_Request * req = new MPI_Request ;

    //    MPI_Status stat ;
        
    vect_mess.push_back (new char [__str.size () + 1]) ;
    strcpy (vect_mess.back (), __str.c_str ()) ;
      
    vect_req.push_back (req) ;

    //    MPI_Isend ((char *) __str.c_str (),
    MPI_Isend (vect_mess.back (),
	       __str.size () + 1,
	       MPI_CHAR,
	       __dest,
	       __tag,
	       MPI_COMM_WORLD,
	       vect_req.back ()) ;
    //    MPI_Wait (& req, & stat) ;
    //vect_req.push_back () ;
  }
  
#ifdef HAVE_SSTREAM
  void eoComm :: send (unsigned __tag,
		       unsigned __dest,
		       std :: ostringstream & __os) {
    __os << '\0' ;
    send (__tag, __dest, __os.str ()) ;
  }
  
#else
  void eoComm :: send (unsigned __tag,
		       unsigned __dest,
		       std :: ostrstream & __os) {
    __os << '\0' ;
    send (__tag, __dest, __os.str ()) ; 
  }
#endif
  
  void eoComm :: receive (unsigned __tag,
			  unsigned __src,
			  std :: string & __str) {
    
    cleanBuffers () ;

    MPI_Status stat ;

    MPI_Request req ;
    int len ;
    
    MPI_Probe (__src, __tag, MPI_COMM_WORLD, & stat) ;
    MPI_Get_count (& stat, MPI_CHAR, & len) ;
    
    char * buff = new char [len] ;
    
    //MPI_Irecv (buff, len, MPI_CHAR, __src, __tag, MPI_COMM_WORLD, & stat) ;
    MPI_Irecv (buff, len, MPI_CHAR, __src, __tag, MPI_COMM_WORLD, & req) ;
    MPI_Wait (& req, & stat) ;
    __str.assign (buff) ;
    
    delete [] buff ;
  }
  
  bool eoComm :: probe (unsigned __tag,
			unsigned __src) {
    
    cleanBuffers () ;

    MPI_Status stat ;
    int flag ;
    
    MPI_Iprobe (__src, __tag, MPI_COMM_WORLD, & flag, & stat) ;
    
    return flag ;
  }
  
  bool eoComm :: probeAnySource (unsigned __tag) {
    
    cleanBuffers () ;

    MPI_Status stat ;
    int flag ;
      
    MPI_Iprobe (MPI_ANY_SOURCE, __tag, MPI_COMM_WORLD, & flag, & stat) ;
    
    return flag ;
  } 
  
  bool eoComm :: probeAnyTagAnySource () {
    
    cleanBuffers () ;

    MPI_Status stat ;
    int flag ;
    
    MPI_Iprobe (MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, & flag, & stat) ;
    
    return flag ;
  }
  
  void eoComm :: waitAnyTagAnySource () {
    
    cleanBuffers () ;

    MPI_Status stat ;
      
    MPI_Probe (MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, & stat) ;
  }
  
  int eoComm :: rank () {

    return rk ;
  }
  
  int eoComm :: size () {
    
    return len ;
  }
  
  void eoComm :: terminate () {
    /*    
    for (unsigned i = 0 ; i < vect_req.size () ; i ++) {
      
      MPI_Status stat ;
      MPI_Wait (vect_req [i], & stat) ;
      }*/

    MPI_Finalize () ;    
  }
} 


