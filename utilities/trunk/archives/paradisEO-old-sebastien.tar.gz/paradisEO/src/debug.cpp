// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "debug.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <unistd.h>
#include <iostream>

#include "eoChan.h"

static bool verb = false ;

static char host_name [200] ;

bool verbose () {
  
  return verb ;
}

void displayDateAndLocation () ;

void setVerbose () {
  
  verb = true ;
 
  gethostname (host_name, 200) ;
  displayDateAndLocation () ;
  std :: cout << "beginning" << std :: endl ;
}

void displayDateAndLocation () {
  
  // Date
  time_t t ;
  time (& t) ;
  struct tm * tt = localtime (& t) ;
  std :: cout << '[' ;
     
  unsigned hours = tt -> tm_hour ;
  if (hours < 10)
    std :: cout << '0' ;
  std :: cout << hours << ':' ;
  
  unsigned min = tt -> tm_min ;
  if (min < 10)
    std :: cout << '0' ;
  std :: cout << min << ':' ;
  
  unsigned sec = tt -> tm_sec ;
  if (sec < 10)
    std :: cout << '0' ;
  std :: cout << sec << "] " ;
  
  std :: cout << '<' << host_name << ">: " ;
}
