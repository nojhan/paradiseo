// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoStopChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <iostream>
#include <string>

#include "eoStopChan.h"
#include "debug.h"

eoStopChan :: eoStopChan (eoNamingChan & __namChan
			  ) : eoChan ("eoStopChan"),
			      namChan (__namChan),			      
			      thisIsTheEnd (false) {
  if (comm)
    init () ;
  else
    awaiting_channels.push_back (this) ;
}

void eoStopChan :: init () {
  
  eoChan :: init () ;

  //  howManyAreAlive = comm -> rank () == comm -> size () - 1 ? 0 : 1 ; 
    howManyAreAlive = 1 ;
}

bool eoStopChan :: update () {
  
  bool b = false ;

  while (comm -> probeAnySource (tag)) 
    
    for (int i = 0 ; i < comm -> size () ; i ++) 
      
      if (comm -> probe (tag, i)) {
	b = true ;


	std :: string str ;
	comm -> receive (tag, i, str) ;

	if (str == "That's over for you :-) !!!") {
	  thisIsTheEnd = true ;
	}
	
	else {// That's over for me :-) !!! 
	  
	  howManyAreAlive -- ;
	}
      }
  return b ;
}

bool eoStopChan :: notifiedOfTermination () {
  
    return thisIsTheEnd ;
}

void eoStopChan :: terminate (unsigned __dest) {
  
  comm -> send (tag, __dest, "That's over for you :-) !!!") ;
}

void eoStopChan :: terminate () {
    
  if (! comm -> rank ()) {
    comm -> send (tag, comm -> size () - 1, "That's over for me :-) !!!") ;

  }
  while (howManyAreAlive) {
    
    comm -> waitAnyTagAnySource () ;
    eoChan :: updateAll () ;
  }

  if (comm -> rank ())
    comm -> send (tag, comm -> rank () - 1, "That's over for me :-) !!!") ;
  
  comm -> terminate () ;
}

void eoStopChan :: wait (const std :: string & __label) {
  
  do {
    
    bool ok = true ;
    updateAll () ;
    
    for (int i = 0 ; i < comm -> size () ; i ++)
      if (namChan [i] == __label)
	ok = false ;
    
    if (ok)
      return ;
    else
      comm -> waitAnyTagAnySource () ;

  } while (true) ;
}

void eoStopChan :: terminate (const std :: string & __dest) {
  
  if (! comm -> rank ()) {
    
    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "terminating " << __dest << std :: endl ;   
    }

    for (unsigned i = 0 ; i < namChan.size () ; i ++) {
      
      if (strstr (namChan [i].c_str (), __dest.c_str ())) {
	
	terminate (i) ;
	
	do
	  eoChan :: updateAll () ;
	while (namChan [i] != "?") ;
	
      }
    }    
  }
}
