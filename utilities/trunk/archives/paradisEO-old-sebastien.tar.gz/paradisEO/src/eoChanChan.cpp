// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoChanChan.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "eoChanChan.h"

std :: map <std :: string, int> eoChanChan :: mapTag ;

eoChanChan :: eoChanChan () : eoChan ("eoChanChan") {
  
  if (comm)
    init () ;
  else
    awaiting_channels.push_back (this) ;
}

void eoChanChan :: declare (eoChan * __chan, const std :: string & __className) {
  
  if (! countTag || // Channel of channels ;-)
      ! comm -> rank ()) { // The "Master" process
        
    /* rank () -> 0 "Master". Initialization of the listener's tag
       from the shared tag count, which is then updated */
    __chan -> tag = countTag ++ ; // Post inc. 
    mapTag [__className] = __chan -> tag ;
  }
  else if (mapTag [__className])
    __chan -> tag = mapTag [__className] ;
  
  else {
    // Not used yet ...

    // Asking the leader process ...
    comm -> send (tag, 0, __className) ;
    
    // Waiting for sync. to be done ... 
    blocked = true ;
    
    while (blocked) {
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    }      
    
    __chan -> tag = machinchouette ;
    mapTag [__className] = __chan -> tag ;
  }
}

bool eoChanChan :: update () {
    

  bool r = false ;

  if (comm -> isLeader ()) {
    // Master [0]. Receiving a request
    
    while (comm -> probeAnySource (tag)) {
      for (int i = 0 ; i < comm -> size () ; i ++)
	if (comm -> probe (tag, i)) {
	  
	  r = true ;

	  std :: string str ;
	  
	  comm -> receive (tag, i, str) ;	    
	  if (! mapTag [str])
	    mapTag [str] = countTag ++ ;
	  
#ifdef HAVE_SSTREAM
	  std :: ostringstream os ;
#else
	  std :: ostrstream os ;
#endif
	  os << mapTag [str] ;
	  comm -> send (tag, i, os) ;
	}
    }
  }
  else if (comm -> probe (tag, 0)) {
    /* Receiving the response
       of the master */
    
    std :: string str ;
    
    comm -> receive (tag, 0, str) ;
    machinchouette = atoi (str.data ()) ; // :-)
    blocked = false ;
    r = true ;
  }
  return r ;
}
