// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoTimeContinue.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr  
*/

#ifndef eoTimeContinue_h
#define eoTimeContinue_h

#include <eoContinue.h>

#include <time.h>

template <class EOT> class eoTimeContinue : public eoContinue <EOT> {
  
public :
  
  /** Constructor */
  eoTimeContinue (unsigned __span
		  ) : span (__span),
		      _time (0) {

  }
  
  /** For a given population */
  bool operator () (const eoPop <EOT> & __pop) {
    
    if (! _time)
      _time = time (0) ;
    
    if (time (0) > _time + span) {
      _time = time (0) + span ;
      
      return false ;
    }
    else
      return true ;
    
  }

private :
  
  unsigned span ;
  
  int _time ; 
} ;

#endif
