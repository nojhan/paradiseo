// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistPopEvalFunc.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistPopEvalFunc_h
#define eoDistPopEvalFunc_h

#include <algorithm>

#include <eoPop.h>
#include <eoPopEvalFunc.h>

#include "eoAggEvalFunc.h"
#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoPopChan.h"
#include "eoFitChan.h"
#include "eoStopChan.h"

template <class EOT> class eoDistPopEvalFunc : public eoPopEvalFunc <EOT> {

public :

  typedef typename EOT :: Fitness Fit ;
  
  /** Constructor */
  eoDistPopEvalFunc (eoNamingChan & __namChan,
		     eoSchedulingChan & __schedChan,
		     eoPopChan <EOT> & __popChan,
		     eoFitChan <EOT> & __fitChan,
		     const std :: vector <std :: string> & __labels,
		     eoAggEvalFunc <EOT> & __aggFunc,
		     unsigned __size_unit = 1
		     ) : namChan (__namChan),
			 schedChan (__schedChan),
			 popChan (__popChan),
			 fitChan (__fitChan),
			 labels (__labels),
			 aggFunc (__aggFunc),
			 size_unit (__size_unit) {    
    
  }
  
  /** For a population of parents and children */
  void operator () (eoPop <EOT> & __parents, eoPop <EOT> & __offspring) {
    /* Notes. '_parents' is discarded ! (See. TimeVarying ...)
       Individuals in a population will be mixed */
    
    std :: vector <std :: queue <unsigned> > vectPos ;
    
    vectPos.resize (popChan.size ()) ;
    
    unsigned pos = 0, num = 0 ;
    
    while (pos < __offspring.size ()) {
      
      eoPop <EOT> pop ;
      
      for (unsigned j = pos ; j < std :: min (pos + size_unit, (unsigned) __offspring.size ()) ; j ++)
	pop.push_back (__offspring [j]) ;
      
      for (unsigned j = 0 ; j < labels.size () ; j ++) {

	unsigned rk = schedChan.wait (labels [j]) ;
	
	popChan.send (rk, pop) ; 
	vectPos [rk].push (pos) ;
	num ++ ;
	if (verbose ()) {
	  displayDateAndLocation () ;
	  std :: cout << "sending a set of individuals for evaluation" << std :: endl ;   
	}
      }

      pos = std :: min (pos + size_unit, (unsigned) __offspring.size ()) ;           
    }
    
    std :: vector <std :: vector <Fit> > vectFit ;

    vectFit.resize (__offspring.size ()) ;
    
    unsigned n = 0 ;

    while (n < num) {
      
      fitChan.wait () ;
      
      for (unsigned i = 0 ; i < fitChan.size () ; i ++)
	  while (! fitChan [i].empty ()) {
	    
	    std :: vector <Fit> & v = fitChan [i].front () ;
	    
	    unsigned from = vectPos [i].front () ;
	    
	    vectPos [i].pop () ;
	    
	    for (unsigned j = 0 ; j < v.size () ; j ++)	      
	      vectFit [from + j].push_back (v [j]) ;
	    
	    fitChan [i].pop () ;
	    n ++ ;
	    
	    if (verbose ()) {
	      displayDateAndLocation () ;
	      std :: cout << "receiving a set of partial computed fitnesses" << std :: endl ;   
	    }
	  }
    }
    
    if (verbose ()) {
      displayDateAndLocation () ;
      std :: cout << "merging partial computed fitnesses" << std :: endl ;   
    }

    for (unsigned i = 0 ; i < vectFit.size () ; i ++) 
      aggFunc (__offspring [i], vectFit [i]) ;
  }
  
private :

  eoNamingChan & namChan ;
  
  eoSchedulingChan & schedChan ; 

  eoPopChan <EOT> & popChan ; 

  eoFitChan <EOT> & fitChan ; 

  const std :: vector <std :: string> labels ; 

  eoAggEvalFunc <EOT> & aggFunc ;
  
  unsigned size_unit ;  
} ;

#endif
