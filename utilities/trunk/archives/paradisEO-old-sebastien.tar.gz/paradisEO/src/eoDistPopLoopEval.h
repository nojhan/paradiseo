// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistPopLoopEval.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistPopLoopEval_h
#define eoDistPopLoopEval_h

#include <queue>
#include <algorithm>

#include <eoPop.h>
#include <eoPopEvalFunc.h>

#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoPopChan.h"
#include "eoFitChan.h"
#include "eoStopChan.h"

/** ? */
template <class EOT> class eoDistPopLoopEval : public eoPopEvalFunc <EOT> {
  
public :
  
  /** Constructor */
  eoDistPopLoopEval (eoNamingChan & __namChan,
		     eoSchedulingChan & __schedChan,
		     eoPopChan <EOT> & __popChan,
		     eoFitChan <EOT> & __fitChan,
		     std :: string __label,
		     unsigned __size_unit = 1
		     ) : 
    namChan (__namChan),
    schedChan (__schedChan),
    popChan (__popChan),
    fitChan (__fitChan),
    label (__label),
    size_unit (__size_unit) {    
    
  }
  
  /** For a population of parents
      and children */
  void operator () (eoPop <EOT> & __parents,
		    eoPop <EOT> & __offspring) {
    /* Notes. '_parents' is discarded ! (See. TimeVarying ...)
       Individuals in a population will be mixed */
   
    std :: vector <std :: queue <unsigned> > vectPos ;
    
    vectPos.resize (popChan.size ()) ;

    unsigned pos = 0 ;
    
    while (pos < __offspring.size ()) {
      
      eoPop <EOT> pop ;
      
      for (unsigned j = pos ; j < std :: min (pos + size_unit, (unsigned) __offspring.size ()) ; j ++)
	pop.push_back (__offspring [j]) ;
      
      unsigned rk = schedChan.wait (label) ;
      
      popChan.send (rk, pop) ;      
      vectPos [rk].push (pos) ;

      if (verbose ()) {
	displayDateAndLocation () ;
	std :: cout << "sending a set of individuals for evaluation" << std :: endl ;   
      }
      
      pos = std :: min (pos + size_unit, (unsigned) __offspring.size ()) ;     
    }
    
    pos = 0 ;
    
    while (pos < __offspring.size ()) {
      
      fitChan.wait () ;
      
      for (unsigned i = 0 ; i < fitChan.size () ; i ++)
	if (namChan [i] == label)
	  while (! fitChan [i].empty ()) {
	    
	    std :: vector <typename EOT :: Fitness> & vectFit = fitChan [i].front () ;
	    
	    unsigned from = vectPos [i].front () ;
	    vectPos [i].pop () ;
	    
	    for (unsigned j = 0 ; j < vectFit.size () ; j ++)
	      __offspring [from + j].fitness (vectFit [j]) ;
	    pos += vectFit.size () ;
	    
	    if (verbose ()) {
	      displayDateAndLocation () ;
	      std :: cout << "receiving a set of computed fitnesses" << std :: endl ;   
	    }
	    
	    fitChan [i].pop () ;
	  }
    }
  }
  
private :
  
  eoNamingChan & namChan ;
  
  eoSchedulingChan & schedChan ; 

  eoPopChan <EOT> & popChan ; 

  eoFitChan <EOT> & fitChan ; 

  std :: string label ; // Of the evaluating nodes

  unsigned size_unit ;
} ;

#endif
