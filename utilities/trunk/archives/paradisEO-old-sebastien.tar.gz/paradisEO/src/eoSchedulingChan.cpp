// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoSchedulingChan.cpp"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "eoSchedulingChan.h"
#include "eoNamingChan.h"

#ifdef HAVE_SSTREAM
#include <sstream>
#else
#include <strstream>
#endif

#define SET_IDLE 0
#define ASK_WORKER 1
#define PROVIDE_WORKER 2

eoSchedulingChan :: eoSchedulingChan (eoNamingChan & __namChan
				      ) : eoChan ("eoSchedulingChan"),
					  namChan (__namChan) {
  
  if (comm)
    init () ;
  else
    awaiting_channels.push_back (this) ;
}

void eoSchedulingChan :: init () {
  
  eoChan :: init () ;

  busy.resize (comm -> size ()) ;
  for (int i = 0 ; i < comm -> size () ; i ++)
    busy [i] = false ;

  // For logging
  logging.resize (comm -> size ()) ;
  for (unsigned i = 0 ; i < logging.size () ; i ++) {
    
    logging [i].resize (comm -> size ()) ;
    
    for (unsigned j = 0 ; j < logging [i].size () ; j ++)
      logging [i] [j] = 0 ;
  }  
}

eoSchedulingChan :: ~ eoSchedulingChan () {
  
  // Nothing ! :-)
}

unsigned eoSchedulingChan :: wait (const std :: string & __label) {

#ifdef HAVE_SSTREAM  
  std :: ostringstream os ;
#else
  std :: ostrstream os ;
#endif

  os << ASK_WORKER << ' ' << __label ;
  comm -> send (tag, 0, os) ;

  blocked = true ;
  
  while (blocked) {
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
  }      
  
  return rankOfFreeNode ;
}

void eoSchedulingChan :: setIdle () {

#ifdef HAVE_SSTREAM  
  std :: ostringstream os ;
#else
  std :: ostrstream os ;
#endif
  
  os << SET_IDLE ;
  
  comm -> send (tag, 0, os) ; // To the leader process
}

void eoSchedulingChan :: displayStats (std :: ostream & __os) {
  
  if (comm -> isLeader ()) { 
    for (unsigned i = 0 ; i < logging.size () ; i ++) {
      
      __os << '[' << i << "] '" << namChan [i] << "\':" ;
      
      for (unsigned j = 0 ; j < logging [i].size () ; j ++)
	__os << '(' << j << ", " << logging [i] [j] << ") " ;
      __os << std :: endl ;
    }
  }
}

void eoSchedulingChan :: useFreeWorkers () {
  
  for (unsigned i = 0 ; i < busy.size () ; i ++)
    if (! busy [i]) {
      
      const std :: string & label = namChan [i] ;
      
      std :: vector <unsigned> & locWaitReq = waitReq [label] ;
      
      if (locWaitReq.size ()) {

	std :: vector <unsigned> & weights = trace [label] ;
	weights.resize (comm -> size ()) ;

	unsigned winner = locWaitReq [0], winner_weight = weights [winner], winner_rk = 0 ;
	
	for (unsigned j = 1 ; j < locWaitReq.size () ; j ++)
	  
	  if (weights [locWaitReq [j]] < winner_weight) {
	    
	    winner_weight = weights [locWaitReq [j]] ;
	    winner_rk = j ;
	    winner = locWaitReq [j] ;
	  }
	
#ifdef HAVE_SSTREAM  
	std :: ostringstream os ;
#else
	std :: ostrstream os ;
#endif
	
	os << PROVIDE_WORKER << ' ' << i ;
	comm -> send (tag, winner, os) ;
	weights [winner] ++ ;
	
	locWaitReq [winner_rk] = locWaitReq.back () ;
	locWaitReq.pop_back () ;
	(logging [i] [winner]) ++ ;	
	busy [i] = true ;
      }
    }
}

bool eoSchedulingChan :: update () {
  
  bool r = false ;

  while (comm -> probeAnySource (tag)) {
    
    for (int i = 0 ; i < (int) comm -> size () ; i ++)
      if (comm -> probe (tag, i)) {
	
	r = true ;

	std :: string mess ;
	
	comm -> receive (tag, i, mess) ;	
	
#ifdef HAVE_SSTREAM  
	std :: istringstream is ;
#else
	std :: istrstream is ;
#endif
	
	is.str (mess) ;
	
	unsigned code ;
	
	is >> code ;
	
	if (code == SET_IDLE)
	  // SET_IDLE

	  busy [i] = false ;
	
	else if (code == ASK_WORKER) {
	  // ASK_WORKER
	  
	  std :: string label ;
	  
	  is >> label ;
	  waitReq [label].push_back (i) ; 
	  //  std :: cout << "Requete de " << i << std :: endl ;
	}
	else {
	  // PROVIDE_WORKER
	  
	  is >> rankOfFreeNode ;
	  blocked = false ;	  
	}
      }
  }
  if (comm -> isLeader ()) 
    useFreeWorkers () ;
  return r ;
}
