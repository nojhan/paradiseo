// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoStopChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoStopChan_h
#define eoStopChan_h

#include "eoNamingChan.h"

/** */
class eoStopChan : public eoChan {
  
public :
  
  /** Constructor */
  eoStopChan (eoNamingChan & __namChan) ;

  /** Initialization */
  void init () ;
  
  /** Processing incoming messages */
  bool update () ;

  /** Another process has requested the current
      node to stop its activity */
  bool notifiedOfTermination () ;
  
  /** The current node is terminating */
  void terminate () ;

  void terminate (const std :: string & __dest) ; 
  
  /** Waiting some other processes
      to terminate */
  void wait (const std :: string & __label) ;
  
private :

  /** Stops a distant process expressed by its own integer identifiant */
  void terminate (unsigned __dest) ;

  eoNamingChan & namChan ;

  bool thisIsTheEnd ;

  int howManyAreAlive ;
  
} ;

#endif
