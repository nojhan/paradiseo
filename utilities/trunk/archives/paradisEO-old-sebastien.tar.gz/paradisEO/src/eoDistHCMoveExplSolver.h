// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistHCMoveExplSolver.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistHCMoveExplSolver_h
#define eoDistHCMoveExplSolver_h

#include "eoDistMoveExplSolver.h"

#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoStopChan.h"
#include "eoMoveChan.h"
#include "eoEOChan.h"
#include "eoFitChan.h"
#include "debug.h"

#include <eoMoveInit.h>
#include <eoNextMove.h>
#include <eoMoveIncrEval.h>
#include <eoMoveSelect.h>

/** */
template <class M> class eoDistHCMoveExplSolver : public eoDistMoveExplSolver <M> {
  
  /* Alias */
  typedef typename M :: EOType EOT ;
  
  typedef typename M :: EOType :: Fitness Fitness ;
  
public :

  /** Constructor */
  eoDistHCMoveExplSolver (eoNamingChan & __namChan,
			  eoSchedulingChan & __schedChan,
			  eoStopChan & __stopChan,
			  eoMoveChan <M> & __moveChan,	       
			  eoEOChan <EOT> & __EOChan,
			  eoFitChan <EOT> & __fitChan,
			  
			  eoMoveInit <M> & __move_init,
			  eoNextMove <M> & __next_move,
			  eoMoveIncrEval <M> & __incr_eval,
			  eoMoveSelect <M> & __move_select,
			  
			  const std :: string & __label
		       ) :    
    namChan (__namChan),
    schedChan (__schedChan),
    stopChan (__stopChan),
    moveChan (__moveChan),
    EOChan (__EOChan),
    fitChan (__fitChan),    
    
    move_init (__move_init),
    next_move (__next_move),
    incr_eval (__incr_eval),
    move_select (__move_select),
    
    label (__label) {
    
    // Empty !
  }
  
  void operator () () {
    
    namChan.publish (label) ; 
    
    while (! stopChan.notifiedOfTermination ()) {
      
      EOChan.wait () ;
      
      for (unsigned i = 0 ; i < EOChan.size () ; i ++)
	if (! EOChan [i].empty ()) {
	  
	  EOT & sol = EOChan [i].front () ;

	  if (verbose ()) {
	    displayDateAndLocation () ;
	    std :: cout << "starting the partial exploration of the received solution" << std :: endl ;   
	  }
	  	  
	  M move ;

	  //
	  move_init (move, sol) ; /* Restarting the exploration of 
				       of the neighborhood ! */
	  
	  move_select.init (sol.fitness ()) ;
	  
	  while (move_select.update (move, incr_eval (move, sol)) && next_move (move, sol)) ;
	  
	  try {
	    
	    M best_move ;
	    Fitness best_move_fit ;
	    
	    move_select (best_move, best_move_fit) ;	    
	    moveChan.send (i, best_move) ;
	    fitChan.send (i, std :: vector <Fitness> (1, best_move_fit)) ;	    

	    if (verbose ()) {
	      displayDateAndLocation () ;
	      std :: cout << "sending back the choosen move and associated new fitness" << std :: endl ;   
	    }	    
	  }     
	  catch (EmptySelection & __ex) {
	    
	    fitChan.send (i, std :: vector <Fitness> (1, 0)) ;	    
	  } 	  

	  EOChan [i].pop () ;
	  
	  schedChan.setIdle () ;
	}
    }
    namChan.publish ("?") ; 
  }

private :
  
  eoNamingChan & namChan ;
  
  eoSchedulingChan & schedChan ;
  
  eoStopChan & stopChan ;
  
  eoMoveChan <M> & moveChan ;	       

  eoEOChan <EOT> & EOChan ;
  
  eoFitChan <EOT> & fitChan ;

  eoMoveInit <M> & move_init ; // Init.

  eoNextMove <M> & next_move ; /* Neighborhood
				  explorer */

  eoMoveIncrEval <M> & incr_eval ; // Efficient eval.

  eoMoveSelect <M> & move_select ; // Move selector

  std :: string label ;
 
} ;

#endif
