// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistPopLoopSolver.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistPopLoopSolver_h
#define eoDistPopLoopSolver_h

#include <string>

#include <eoEvalFunc.h>

#include "eoNamingChan.h"
#include "eoSchedulingChan.h"
#include "eoStopChan.h"
#include "eoPopChan.h"
#include "eoFitChan.h"
#include "debug.h"

/** ??? */
template <class EOT> class eoDistPopLoopSolver {
  
public :
  
  /** Constructor */
  eoDistPopLoopSolver (eoNamingChan & __namChan,
		       eoSchedulingChan & __schedChan,
		       eoStopChan & __stopChan,
		       eoPopChan <EOT> & __popChan,	       
		       eoFitChan <EOT> & __fitChan,
		       eoEvalFunc <EOT> & __eval,
		       const std :: string & __label
		       ) : 
    namChan (__namChan),
    schedChan (__schedChan),
    stopChan (__stopChan),
    popChan (__popChan),
    fitChan (__fitChan),
    eval (__eval),
    label (__label) {
    
    // Empty !
  }
  
  /** */
  void operator () () {
    
    namChan.publish (label) ; 
        
    while (! stopChan.notifiedOfTermination ()) {
      
      popChan.wait () ;
      
      for (unsigned i = 0 ; i < popChan.size () ; i ++)
	if (! popChan [i].empty ()) {

	  if (verbose ()) {
	    displayDateAndLocation () ;
	    std :: cout << "receiving a set of indiviuals for evaluation" << std :: endl ;   
	  }
	  	  
	  eoPop <EOT> & pop = popChan [i].front () ;

	  std :: vector <typename EOT :: Fitness> vectFit ;
	  
	  for (unsigned j = 0 ; j < pop.size () ; j ++) {
	    eval (pop [j]) ;
	    vectFit.push_back (pop [j].fitness ()) ;
	  }
	  
	  popChan [i].pop () ;
	  
	  fitChan.send (i, vectFit) ;
	  
	  schedChan.setIdle () ;
	}   
    }
    namChan.publish ("?") ; 
  }
  
private :
  
  eoNamingChan & namChan ; // Naming
  
  eoSchedulingChan & schedChan ; // Scheduling
  
  eoStopChan & stopChan ; // Stopping
  
  eoPopChan <EOT> & popChan ; // For evolving objects
  
  eoFitChan <EOT> & fitChan ; // For fitnesses

  eoEvalFunc <EOT> & eval ; /* The action to perform to every 'T' object
			       that is received */
  
  const std :: string label ; /* The given label in order to be known
				 in the community */
} ;

#endif
