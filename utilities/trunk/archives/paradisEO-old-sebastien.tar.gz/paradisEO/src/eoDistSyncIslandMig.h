// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistSyncIslandMig.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistSyncIslandMig_h
#define eoDistSyncIslandMig_h

#include <eoContinue.h>
#include <eoSelect.h>
#include <eoReplacement.h>

#include "eoNamingChan.h"
#include "eoPopChan.h"
#include "eoTopology.h"
#include "debug.h"

/** In a distributed environnment, its manages with migrations.
    Needs of immigration are processed, immigrants
    are assimilated, and then the need of immigration
    for the local pop. occurs periodically */
template <class EOT> class eoDistSyncIslandMig : public eoContinue <EOT> {
  
public :
 
  /** Constructor */
  eoDistSyncIslandMig (eoNamingChan & __namingChan,
		       eoPopChan <EOT> & __popChan,		
		       unsigned __freq,		   
		       eoSelect <EOT> & __select,
		       eoReplacement <EOT> & __replace,
		       eoTopology & __topo   
		       ) :
    namingChan (__namingChan),
    popChan (__popChan),
    freq (__freq),
    iter (0),
    select (__select),
    replace (__replace),
    topo (__topo) {
    
  }
  
  bool operator () (const eoPop <EOT> & __pop) {
    /* Warning !!! The 'const' is discarded. Not nice at all :-/
       But I don't think there is a better way
       to in a different way by reusing 'eoEasyEA'  :-) */ 
    
    /* Updating incoming messages ... */
    
    if (! iter)
      namingChan.sync () ;

    if (! ((++ iter) % freq)) {
            
      eoChan :: updateAll () ;
      
      // Emigrants
      std :: vector <unsigned> neigh_in, neigh_out ;
      topo (neigh_in, neigh_out) ;
      
      if (verbose ()) {
	displayDateAndLocation () ;
	std :: cout << "sending emigrants" << std :: endl ;   
      }

      for (unsigned i = 0 ; i < neigh_out.size () ; i ++) {
	eoPop <EOT> emm ;
	select (__pop, emm) ;
	popChan.send (neigh_out [i], emm) ;
      }
      
      // Immigrants
      for (unsigned i = 0 ; i < neigh_in.size () ; i ++) {
	
	do 
	  popChan.wait () ;
	while (popChan [neigh_in [i]].empty ()) ;
	
	eoPop <EOT> & imm = popChan [neigh_in [i]].front () ;
	
	// New immigrants to integrate into the current local population
	// Ouch ;-/ The following line is really ugly :-)
	replace (const_cast <eoPop <EOT> &> (__pop), imm) ;
	
	if (verbose ()) {
	  displayDateAndLocation () ;
	  std :: cout << "assimilating immigrants" << std :: endl ;   
	}
  	
	popChan [neigh_in [i]].pop () ;
      }
    } 
   
    return true ;
  }
  
private :
  
  eoNamingChan & namingChan ; // Naming channel

  eoPopChan <EOT> & popChan ; // Pop. channel
  
  unsigned freq, iter ; // Frequency of migrations, and the current iteration
  
  eoSelect <EOT> & select ; // To select emigrants
  
  eoReplacement <EOT> & replace ; // To integrate immigrants
  
  eoTopology & topo ; // The used topology
} ;

#endif
