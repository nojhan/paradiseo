// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoChan_h
#define eoChan_h

#include <map>
#include <string>

#include <eoObject.h>

#include "eoComm.h"

class eoChanChan ;

/** The abstract class for all channels that inheritate from it */
class eoChan : public eoObject {
  
public :
  
  /** Constructor */
  eoChan (const std :: string & __str) ;
  
  /** Processing incoming messages (for this channel only !) */
  virtual bool update () = 0 ;

  /** Label of the class ? */
  std :: string className () const ;
  
  static void use (eoComm & __comm) ;
  
  /** Processing any messages for all the registered channels */
  static bool updateAll () ; 

  static eoComm & accessComm () ;
 
protected :

  /** Intialisation */
  virtual void init () ;
  
  int tag ; // Integer id. (<-> Type)
  
  static int countTag ; // Counter of tags

  static std :: map <std :: string, eoChan *> mapChan ; /* Storing all the
							   registered channels */
  
  static eoComm * comm ; // Communicator

  static std :: vector <eoChan *> awaiting_channels ;

  std :: string name ;

  // A very particular channel :-)
  static eoChanChan * chanChan ;
 
  friend class eoChanChan ;
  
} ;

#endif
