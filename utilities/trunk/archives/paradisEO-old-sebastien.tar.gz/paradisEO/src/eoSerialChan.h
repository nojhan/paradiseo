// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoSerialChan.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoSerialChan_h
#define eoSerialChan_h

#include <queue>
#include <vector>

#include "eoChan.h"
#include "eoNamingChan.h"

/** A generic class to send/receive some kind of data that
    are said to be 'serializable' */
template <class T> class eoSerialChan : public eoChan, public std :: vector <std :: queue <T> > {
  
public :
  
  /** Constructor */
  eoSerialChan (std :: string __className) : eoChan (__className) {
        
  }

  /** Initialization */
  void init () {
    
    eoChan :: init () ;
    resize (comm -> size ()) ;
  }
  
  /** Processing incoming messages
      (i.e. receiving and storing some T objects */
  bool update () {
    
    bool r = false ;
    
    while (comm -> probeAnySource (tag)) {
      
      for (unsigned i = 0 ; i < size () ; i ++) {
	if (comm -> probe (tag, i)) {
	  
	  r= true ;
	  operator [] (i).push (T ()) ;
	  
	  std :: string str ;
	  comm -> receive (tag, i, str) ;
	  unserialize (operator [] (i).back (), str) ;
	}
      }
    }
    return r ;
  }

  void wait () {

    bool r = updateAll () ;
          
    for (unsigned i = 0 ; i < size () ; i ++)
      if (! operator [] (i).empty ())
	return ;
    
    if (! r) {      
      comm -> waitAnyTagAnySource () ;
      updateAll () ;
    } 
  }
    
  /** Sends the given 'T' object */
  void send (unsigned __dest, const T & __t) {
    
    std :: string str ;
    serialize (__t, str) ;
    comm -> send (tag, __dest, str) ;
  }
               
protected :
  
  // To be implemented in subclasses ...

  virtual void serialize (const T & __t, std :: string & __str) = 0 ;
  
  virtual void unserialize (T & __t, const std :: string & __str) = 0 ;
  
} ;

#endif
