// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoParaIslandMig.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoParaIslandMig_h
#define eoParaIslandMig_h

#include <string>
#include <map>
#include <queue>

#include <eoPop.h>
#include <eoContinue.h>
#include <eoSelect.h>
#include <eoReplacement.h>

/** ??? */
template <class EOT> class eoParaIslandMig : public eoContinue <EOT> {
  
public :
 
  /** Constructor */
  eoParaIslandMig (eoContinue <EOT> & _cont,
		   eoContinue <EOT> & _contMig,		   
		   eoSelect <EOT> & _select,
		   eoReplacement <EOT> & _replace  
		   ) : 
    cont (_cont),
    contMig (_contMig),
    select (_select),
    replace (_replace) {
    
  }
  
  /** */
  void bind (eoParaIslandMig <EOT> & _mig) {
    
    outNeigh.push_back (& _mig) ;
  }
    
  /** */
  bool operator () (const eoPop <EOT> & _pop) {
    /* Warning !!! The 'const' is discarded. Not nice at all :-/
       But I don't think there is a better way
       to maintain the code easy  :-) */ 
    
    // Updating incoming messages ...
    
    for (typename std :: map <eoParaIslandMig <EOT> *,
	                      std :: queue <eoPop <EOT> > > :: iterator it = inNeigh.begin () ;
	 it != inNeigh.end () ;
	 it ++) {
      
      // Local queue 
      std :: queue <eoPop <EOT> > & queueImm = it -> second  ;
      
      while (! queueImm.empty ()) {
	
	eoPop <EOT> & imm = queueImm.front () ;
	
	if (imm.empty ()) {
	  /* Meaning a need of
	     immigration was received ! */
	  
	  eoPop <EOT> emm ;
	  select (_pop, emm) ;
	  it -> first -> immigrate (emm, this) ; 	  
	}
	else {
      
	  // New immigrants to integrate into the current local population
	  // Ouch ;-/ The following line is really ugly :-)
	  replace (((eoPop <EOT> &)_pop), imm) ;	  
	}
	queueImm.pop () ;
      }
    }
    
    /* About the need of immigration of new
       neighbouring individuals for
       the current pop. */
    
    if (! contMig (_pop)) {

      eoPop <EOT> needImm ; /* An empty pop. !, that will be
			       considered as a need of immigration */      
      
      for (unsigned i = 0 ; i < outNeigh.size () ; i ++)
	outNeigh [i] -> immigrate (needImm, this) ;
      
    }
    return cont (_pop) ;
  }
  
private :

  eoContinue <EOT> & cont ; // Global continuator of the E.A.
    
  eoContinue <EOT> & contMig ; // To express a need of immigration
  
  eoSelect <EOT> & select ; // To select emigrants
  eoReplacement <EOT> & replace ; // To integrate immigrants
  
  std :: map <eoParaIslandMig <EOT> *, std :: queue <eoPop <EOT> > > inNeigh ; // Incoming neighbours !
  
  std :: vector <eoParaIslandMig <EOT> *> outNeigh ; // Outcoming neighbours !

  /** */
  void immigrate (eoPop <EOT> & _pop,
		  eoParaIslandMig <EOT> * _from) {
    
    inNeigh [_from].push (_pop) ;
  }
} ;

#endif
