// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoPopLoopEvalTask.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoPopLoopEvalTask_h
#define eoPopLoopEvalTask_h

#include <eoPop.h>
#include <eoEvalFunc.h>
#include "eoTask.h"

/** */
template <class EOT> class eoPopLoopEvalTask : public eoTask {
  
public :
  
  /** Constructor */
  eoPopLoopEvalTask (eoEvalFunc <EOT> & _eval,
		     eoPop <EOT> & _pop
		     ) : eval (_eval),
			 pop (_pop) {
    
    pthread_mutex_init (& mutex, NULL) ;
    num_eval = 0 ;
  }
  
  /** */
  void operator () () {
    
    while (true) {
      
      pthread_mutex_lock (& mutex) ;
      unsigned num = num_eval ++ ;
      pthread_mutex_unlock (& mutex) ;
      
      if (num >= pop.size ())
	return ;
      else {
	eval (pop [num]) ;  
      }
    }
  }

private :
  
  eoEvalFunc <EOT> & eval ;
  
  eoPop <EOT> & pop ;
  
  static pthread_mutex_t mutex ;

  static unsigned num_eval ;

} ;

template <class EOT> pthread_mutex_t eoPopLoopEvalTask <EOT> :: mutex ;

template <class EOT> unsigned eoPopLoopEvalTask <EOT> :: num_eval ;

#endif
