// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoDistWorker.h"

// (c) OPAC Team, LIFL, 2003

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef eoDistWorker_h
#define eoDistWorker_h

#include <string>

#include <eoFunctor.h>

#include <paradisEO/eoNamingChan.h>
#include <paradisEO/eoSchedulingChan.h>
#include <paradisEO/eoStopChan.h>
#include <paradisEO/eoPersistentChan.h>
#include <paradisEO/debug.h>

/** ??? */
template <class T> class eoDistWorker {
  
public :
  
  /** Constructor */
  eoDistWorker (eoNamingChan & __namChan,
		eoSchedulingChan & __schedChan,
		eoStopChan & __stopChan,
		eoPersistentChan <T> & __tChan,
		eoUF <T &, void> & __func,
		const std :: string & __label
		) : 
    namChan (__namChan),
    schedChan (__schedChan),
    stopChan (__stopChan),
    tChan (__tChan),
    func (__func),
    label (__label) {
    
    // Empty !
  }
  
  /** */
  void operator () () {
    
    namChan.publish (label) ; 
    
    if (debug :: verbose ()) {
    
      debug :: displayDateAndLocation () ;
      * debug :: os << "ready to work" << std :: endl ;   
    }
    
    
    while (! stopChan.notifiedOfTermination ()) {
      
      tChan.wait () ;
      
      for (unsigned i = 0 ; i < tChan.size () ; i ++)
	if (! tChan [i].empty ()) {
	  	  
	  T & t = tChan [i].front () ;
	  func (t) ;
	  tChan.send (i, t) ;
	  tChan [i].pop () ;
	  schedChan.setIdle () ;
	}   
    }
    namChan.publish ("?") ; 
  }
  
private :
  
  eoNamingChan & namChan ; // Naming
  
  eoSchedulingChan & schedChan ; // Scheduling
  
  eoStopChan & stopChan ; // Stopping
  
  eoPersistentChan <T> & tChan ; // For objects of class 'T' to 'transform'
  
  eoUF <T &, void> & func ; /* The action to perform to every 'T' object
			       that is received */
  
  const std :: string label ; /* The given label in order to be known
				 in the community */
} ;

#endif
