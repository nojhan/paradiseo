// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "main.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

/* EO */
#include <eoPop.h>
#include <apply.h>
#include <eoNDSorting.h>
#include <eoParetoRanking.h>
#include <eoSelectNumber.h>
#include <eoSelectMany.h>
#include <eoSGATransform.h>
#include <eoBreed.h>
#include <eoSelectFromWorth.h>
#include <eoReplacement.h>
#include <eoCtrlCContinue.h>
#include <eoGenContinue.h>
#include <eoEasyEA.h>
#include <eoRandomSelect.h>
#include <eoProportionalCombinedOp.h>


#include <eoCombinedContinue.h>
#include <eoPeriodicContinue.h>
#include <utils/eoCheckPoint.h>

/* MOEO */
#include <moeoArchive.h>
#include <moeoArchiveUpdater.h>
#include <eoProportionalCombinedOp.h>
#include <eoPropCombinedSelectMany.h>
#include <moeoHybridMOLS.h>

/* Rule mining */
#include "param.h"
#include "pretty_print.h"

#include "rule_init.h"
#include "rule_eval.h"

#include "support.h"
#include "confidence.h"
#include "jmeasure.h"
#include "interest.h"
#include "surprise.h"

#include "exch_insert_cross.h"
#include "uniform_cross.h"
#include "rule_value_mut.h"
#include "rule_attr_mut.h"
#include "remove_term_mut.h"
#include "add_term_mut.h"
#include "flip_values_mols.h"
#include "smetric.h"
#include "converg.h"
#include "init_pop.h"

#define POP_SIZE 100 /* Number of individuals */
#define CROSS_RATE 1 /* Cross rate */
#define MUT_RATE 0.1 /* Mutation rate */
#define SELECT_RATE 1 /* global selection rate */
#define POP_SELECT_RATE 0.5 /* Rate of pop. selection */ 
#define ARCH_SELECT_RATE 0.5 /* Rate of archive selection */
#define HYBRID_FREQ 5 /* Hybridization frequency / gen. */
#define HYBRID_SIZE 1 /* Number of rules being 'improved' */
#define REINIT_FREQ 5 /* Reinit. frequency */

int main (int __argc, char **  __argv) {

  //  rng.reseed (1);

  loadParameters (__argc, __argv);

  RuleInit init; /* Building some random rules */

  RuleEval eval; /* The multicriterion evaluator */

  eoPop <Rule> pop (POP_SIZE, init); /* Population */ 
  moeoArchive <Rule> arch; /* Archive */
  
  ExchangeInsertCross exch_cross; /* Exchange / Insert crossover */
  UniformCross uniform_cross; /* Uniform crossover */

  eoPropCombinedQuadOp <Rule> cross (exch_cross, 0.5);
  cross.add (uniform_cross, 0.5);

  RuleValueMut value_mut; /* Randomly changing the value for a random attribute */
  RuleAttributeMut attr_mut; /* Randomly changing the attribute itself (with another associated
				value) */
  RemoveTermMut rem_term_mut; /* Randomly removing a term in the rule */
  AddTermMut add_term_mut; /* Randomly adding a term in the rule */

  //eoPropCombinedMonOp <Rule> mut (value_mut, 0.25);
  eoPropCombinedMonOp<Rule> mut (value_mut, 0.25);

  mut.add (attr_mut, 0.25);
  mut.add (rem_term_mut, 0.25);
  mut.add (add_term_mut, 0.25);

  eoNDSorting_II <Rule> perf_to_worth; /* Fast Elitist Non-Dominant Sorting Genetic Algorithm */
  eoRouletteWorthSelect <Rule> select_one (perf_to_worth); /* Selection from the Worthes*/ 
  eoSGATransform <Rule> transform (cross, CROSS_RATE, mut, MUT_RATE); /* It acceps quadratic
									 crossover and unary
									 mutation */

  eoPropCombinedSelectMany <Rule> select (pop, select_one, POP_SELECT_RATE, SELECT_RATE);

  eoRandomSelect <Rule> random_select_one; /* Random selection */
  select.add (arch, random_select_one, ARCH_SELECT_RATE);

  eoSelectTransform <Rule> breed (select, transform); /* Selection followed by Rransformation */
  eoGenerationalReplacement <Rule> replace; /* Generationnal replacement */ 
  
  eoGenContinue <Rule> cont_c (num_gen); /* It continues until the number of gen. is reached */
  eoCtrlCContinue <Rule> cont_gen; /* It continues the evolution until the user pressed <CtrlC> */ 
  eoCombinedContinue <Rule> combined_cont (cont_c, cont_gen);

  eoCheckPoint <Rule> checkpoint (combined_cont); /* Checkpoint */

  moeoArchiveUpdater <Rule> arch_updater (arch, pop); /* Updating the archive from the new generation */
  checkpoint.add (arch_updater);

  /* Hybridization. Selecting some Pareto rules and exploring their neighborhood,
     i.e. testing all the candidate values for every attribute */
  eoPeriodicContinue <Rule> hybrid_cont (HYBRID_FREQ);
  eoSelectNumber <Rule> hybrid_select (random_select_one, HYBRID_SIZE); 
  FlipValuesMOLS hybrid_mols (eval);  
  moeoHybridMOLS <Rule> hybrid (hybrid_cont, hybrid_select, hybrid_mols, arch);
  checkpoint.add (hybrid);

  /* Printing the rules on the screen */  
  PrettyPrintArchUpdater print_arch (arch); 
  checkpoint.add (print_arch); 

  /* Convergence */
  SmetricUpdater smetric (arch);
  checkpoint.add (smetric); 

  /* Divers. */
  eoPeriodicContinue <Rule> init_cont (REINIT_FREQ);
  eoInitPop <Rule> reinit_pop (pop, init, eval, init_cont);
  checkpoint.add (reinit_pop);

  eoEasyEA <Rule> ea (checkpoint, eval, breed, replace); /* Evolutionary Algorithm */

  ea (pop);
  
  return 0;
}
