// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "uniform_cross.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "uniform_cross.h"

static void reduce (Rule & __rule) {
  
  while (__rule.size () > max_terms) {
    
    __rule [1 + rng.random (__rule.size () - 1)] = __rule.back ();
    __rule.pop_back ();
  }
}

bool UniformCross :: operator () (Rule & __father, Rule & __mother) {

  Rule father = __father;
  Rule mother = __mother;

  std :: vector <int> father_att (num_attributes, -1);
  std :: vector <int> mother_att (num_attributes, -1);
  std :: vector <int> son_att (num_attributes, -1);
  std :: vector <int> daughter_att (num_attributes, -1);
  
  for (unsigned i = 1; i < __father.size (); i ++)
    father_att [ATTRIBUTE_KEY(__father [i])] = VALUE_KEY(__father [i]);   
  for (unsigned i = 1; i < __mother.size (); i ++)
    mother_att [ATTRIBUTE_KEY(__mother [i])] = VALUE_KEY(__mother [i]); 

  for (unsigned i = 0; i < num_attributes; i ++)
    if (rng.uniform () < 0.5) {
      son_att [i] = father_att [i];
      daughter_att [i] = mother_att [i];
    }
    else {
      son_att [i] = mother_att [i];
      daughter_att [i] = father_att [i];
    }
  
  father.resize (1);
  mother.resize (1);

  for (unsigned i = 0; i < num_attributes; i ++) {

    if (son_att [i] != -1 && i != ATTRIBUTE_KEY(father.front ()))
      father.push_back (Term (i, son_att [i]));
    if (daughter_att [i] != -1 && i != ATTRIBUTE_KEY(mother.front ()))
      mother.push_back (Term (i, daughter_att [i]));    
  }
  
  if (father.size () < 2)
    father = __father;
  assert (father.size () > 1);  
  reduce (father);
  if (mother.size () < 2)
    mother = __mother;
  assert (mother.size () > 1);  
  reduce (mother);

  __father = father;
  __mother = mother;

  return true;
}
