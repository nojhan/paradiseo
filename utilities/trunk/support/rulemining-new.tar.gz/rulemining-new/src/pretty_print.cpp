// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "pretty_print.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <fstream>
#include <iostream>

#include "pretty_print.h"
#include "rule_eval.h"

#define MAX_BUFF_SIZE 1000

static unsigned prior_obj = 0; /* Sorting the rules */

static void prettyPrint (const Term & __term, std :: ostream & __os) {
  
  __os << '(';
  __os << getAttributeFromKey (__term.first);
  __os << '=';
  __os << getValueFromKey (__term.first, __term.second);
  __os << ')';
  
}

void prettyPrint (const Rule & __rule, std :: ostream & __os) {

  __os << "if (";
  
  for (unsigned i = 1; i < __rule.size (); i ++) {
    prettyPrint (__rule [i], __os);
    if (i == (__rule.size () - 1))
      __os << ')';
    else
      __os << " and ";
  }
  __os << " then ";
  prettyPrint (__rule.front (), __os);
  __os << std :: endl;
}


PrettyPrintArchUpdater :: PrettyPrintArchUpdater (moeoArchive <Rule> & __arch,
						  int __id
						  ) : arch (__arch),
						      id (__id) {

}


struct CompRules : public std :: binary_function <Rule *, Rule *, bool> {
  
  bool operator () (const Rule * __from, const Rule * __to) {
    
    return __from -> fitness () [prior_obj] > __to -> fitness () [prior_obj];
  }    
};


void PrettyPrintArchUpdater :: operator () () {

  //
  std :: vector <const Rule *> v;
  for (unsigned i = 0; i < arch.size (); i ++)
    v.push_back (& arch [i]);
  
  std :: sort (v.begin (), v.end (), CompRules ());

  //
  
  char buff [MAX_BUFF_SIZE];
  
  if (id == -1)
    sprintf (buff, "./res/rules");
  else
    sprintf (buff, "./res/rules.%u", id);
  std :: ofstream f (buff);

  for (unsigned i = 0; i < v.size (); i ++) {
    
    f << '[';
    for (unsigned j = 0; j < v [i] -> fitness ().size (); j ++) {
      f << v [i] -> fitness () [j];
      if (j < v [i] -> fitness ().size () - 1)
	f << ", ";
      else
	f << "] ";
    }
    prettyPrint (* v [i], f);
  }
}

void setPriorObjective (const std :: string & __label) {

  for (unsigned i = 0; i < selected_labels.size (); i ++)
    if (selected_labels [i] == __label) {
      prior_obj = i;
      return;
    }
  printf ("found an unknown priority.\n");
  exit (1);
}
