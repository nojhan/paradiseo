// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "param.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

#include <utils/eoParser.h>

#include "param.h"
#include "data.h"
#include "structure.h"
#include "rule.h"
#include "rule_eval.h"
#include "init.h"
#include "converg.h"
#include "pretty_print.h"

#include <core/peo_debug.h>

bool reverse_data; /* Loading the database (Features / Records) */

void loadParameters (int __argc, char * __argv []) {
//printf ("dealing with '%s'.\n", __argv[0]);
  eoParser parser (__argc, __argv) ;

  /* Structure */
  eoValueParam <std :: string> struct_param ("", "structure", "File describing the structure of the database") ;
  parser.processParam (struct_param) ;
  loadStructure (struct_param.value ().c_str ()); 
  
  /* Contents of the database */
  eoValueParam <std :: string> data_param ("", "database", "File embedding the contents of the database");
  parser.processParam (data_param) ;
  loadDatabase (data_param.value ().c_str ());

  /* Max terms */
  eoValueParam <unsigned> max_terms_param (5, "max_terms", "Max. number of terms allowed in the rule");
  parser.processParam (max_terms_param) ;
  max_terms = max_terms_param.value ();
  printf ("setting the max. number of terms allowed in any rule to %u.\n", max_terms);

  /* Number of gen. */
  eoValueParam <unsigned> num_gen_param (100, "num_gen", "Number of gen.");
  parser.processParam (num_gen_param) ;
  num_gen = num_gen_param.value ();
  printf ("setting the number of gen. to %u.\n", num_gen);
  
  /* Reversa data*/
  eoValueParam <std :: string> reverse_param ("no", "reverse_data", "Reversing the data") ;
  parser.processParam (reverse_param) ;
  reverse_data = reverse_param.value () == "yes";

  /* Objectives */
  eoValueParam <std :: string> obj_param ("???", "objectives", "Model");
  parser.processParam (obj_param);
  //  std :: cout << "##" << obj_param.value () << std :: endl;
  buildEvalModel (obj_param.value ());

  /* Priority */
  eoValueParam <std :: string> sort_param ("?", "sort", "Main objective");
  parser.processParam (sort_param);
  if (sort_param.value () != "?")    
    setPriorObjective (sort_param.value ());  

  /* Verbose */
  eoValueParam <std :: string> verbose_param ("?", "verbose", "Main objective");
  parser.processParam (verbose_param);
//   if (verbose_param.value () == "yes")    
//     setDebugMode ();
  
  /* */
  //  exit (1);

  init ();
}

