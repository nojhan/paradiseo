// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "rule.h"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef __rule_h
#define __rule_h

#include <EO.h>

#include "rule_fit.h"
#include "term.h"

/** The first term is the goal attribute */

class Rule : public EO <RuleFit>, public std :: vector <Term> {

public :

  void printOn (std :: ostream & __os) const;
  
  void readFrom (std :: istream & __is);

  unsigned C; /* | C | */
  
  unsigned P; /* | P | */
  
  unsigned C_and_P; /* | C & P | */
  
  unsigned C_and_noP; /* | C & (- P) | */

  bool operator == (const Rule & __rule) const;
};

extern unsigned max_terms; /* Max. number of attributes */

#endif
