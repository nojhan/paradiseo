// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; messent-column: 35; -*-

// "init_pop.h"

// (c) OPAC Team, LIFL, August 2005

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef __init_pop_h
#define __init_pop_h

#include <eoPop.h>
#include <eoEvalFunc.h>
#include <eoInit.h>
#include <eoContinue.h>
//#include <core/peo_debug.h>
#include <apply.h>

#include <utils/eoUpdater.h>

template <class EOT> class eoInitPop : public eoUpdater {

public :

  /** Constructor */
  eoInitPop (eoPop <EOT> & __pop,
	     eoInit <EOT> & __init,
	     eoEvalFunc <EOT> & __eval,
	     eoContinue <EOT> & __cont);
	     
  void operator () ();

private :

  eoPop <EOT> & pop;
  eoInit <EOT> & init;
  eoEvalFunc <EOT> & eval;
  eoContinue <EOT> & cont;
};

template <class EOT >
eoInitPop <EOT> ::  eoInitPop (eoPop <EOT> & __pop,
			       eoInit <EOT> & __init,
			       eoEvalFunc <EOT> & __eval,
			       eoContinue <EOT> & __cont
			       ) : pop (__pop),
				   init (__init),
				   eval (__eval),
				   cont (__cont) {

}

template <class EOT> 
void eoInitPop <EOT> :: operator () () {
  
  if (! cont (pop)) {
    
    //printDebugMessage ("reinit. the population.");
    apply (init, pop);
    apply (eval, pop);
  }
}

#endif
