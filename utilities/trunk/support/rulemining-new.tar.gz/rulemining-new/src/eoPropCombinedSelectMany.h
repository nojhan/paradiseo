// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "eoPropCombinedSelectMany.h"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef __eoPropCombinedSelectMany_h
#define __eoPropCombinedSelectMany_h

#include <assert.h>

#include <eoSelect.h>
#include <eoSelectOne.h>
#include <utils/eoHowMany.h>

template <class EOT> class eoPropCombinedSelectMany : public eoSelect <EOT> {

public :

  /** Constructor */
  eoPropCombinedSelectMany (eoPop <EOT> & __pop,
			    eoSelectOne <EOT> & __select_one,
			    double __select_one_rate,
			    double __select_rate,
			    bool __interpret_as_rate = true);
			    


  void operator () (const eoPop <EOT> & __from, eoPop <EOT> & __to);
  
  void add (eoPop <EOT> & __pop, eoSelectOne <EOT> & __select_one, double __rate);

private :

  eoHowMany how_many;

  std :: vector <eoPop <EOT> *> pops;

  std :: vector <eoSelectOne <EOT> *> selectors;

  std :: vector <double> rates;

  double sum_rates;
};

template <class EOT> 
eoPropCombinedSelectMany <EOT> :: eoPropCombinedSelectMany (eoPop <EOT> & __pop,
							    eoSelectOne <EOT> & __select_one,
							    double __select_one_rate,
							    double __select_rate,
							    bool __interpret_as_rate
							    ) : how_many (__select_rate,
									  __interpret_as_rate),
								sum_rates (0) {
  
  add (__pop, __select_one, __select_one_rate);
}

template <class EOT> 
void eoPropCombinedSelectMany <EOT> :: add (eoPop <EOT> & __pop,
					    eoSelectOne <EOT> & __select_one,
					    double __rate) {

  pops.push_back (& __pop);
  selectors.push_back (& __select_one);  
  rates.push_back (__rate);
  sum_rates += __rate;
  assert (sum_rates <= 1);
}

template <class EOT> 
void eoPropCombinedSelectMany <EOT> :: operator () (const eoPop <EOT> & __from, eoPop <EOT> & __to) {
  
  std :: vector <unsigned> cand;
  double sum = 0;

  for (unsigned i = 0; i < pops.size (); i ++)
    if (pops [i] -> size () > 1) {
      cand.push_back (i);
      selectors [i] -> setup (* pops [i]);
      sum += rates [i];
    }

  unsigned num = how_many (__from.size ());
  __to.clear ();

  for (unsigned i = 0; i < num; i ++) {

    double r = rng.uniform () * sum, t = 0;
    
    unsigned j = 0;
    
    while ((t += rates [j]) < r)
      j ++;
    __to.push_back (selectors [cand [j]] -> operator () (* pops  [cand [j]]));
  }
}

#endif
