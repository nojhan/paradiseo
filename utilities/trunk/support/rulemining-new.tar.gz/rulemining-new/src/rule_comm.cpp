// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "rule_comm.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "rule_comm.h"
#include "mess.h"

/** Fitness */

static void pack (const RuleFit & __fit) {

  pack (__fit.size ());
  for (unsigned i = 0; i < __fit.size (); i ++)
    pack (__fit [i]);  
}

static void unpack (RuleFit & __fit) {
  
  unsigned sz;
  unpack (sz);
  __fit.resize (sz);
  for (unsigned i = 0; i < sz; i ++)
    unpack (__fit [i]);    
}

/* Term */

static void pack (const Term & __term) {

  pack (__term.first);
  pack (__term.second);
}

static void unpack (Term & __term) {

  unpack (__term.first);
  unpack (__term.second);
}



void pack (const Rule & __rule) {

  /* Fitness */
  pack (__rule.fitness ());

  /* Rule */
  pack ((unsigned) __rule.size ());
  for (unsigned i = 0; i < __rule.size (); i ++)
    pack (__rule [i]);
}

void unpack (Rule & __rule) {

  RuleFit fit;

  /* Fitness */
  unpack (fit);
  __rule.fitness (fit);
  
  /* Rule */
  unsigned sz;
  unpack (sz);
  __rule.resize (sz);
  for (unsigned i = 0; i < sz; i ++)
    unpack (__rule [i]);  
}
