// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "attribute.h"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef __attribute_h
#define __attribute_h

#include <vector>
#include <string>

typedef unsigned AttributeKey; 

typedef unsigned ValueKey; 

struct Attribute {

  std :: string name;

  std :: vector <std :: string> values;

  unsigned num_values;

  /** Constructor */
  Attribute (const std :: string & __name, const std :: vector <std :: string> & __values);
};

extern unsigned num_attributes; /** Total number of attributes */ 

extern std :: vector <Attribute> attributes; /** List of attributes */

extern unsigned num_goal_attributes; /** Total number of goal attributes */ 

extern std :: vector <AttributeKey> goal_attr_keys; /** Subset of goal attributes */

extern void buildAttributeKeys ();

extern AttributeKey getKeyFromAttribute (const char * __value);

extern ValueKey getKeyFromValue (AttributeKey __num_att, const char * __value);  

extern const std :: string & getAttributeFromKey (AttributeKey __key);

extern const std :: string & getValueFromKey (AttributeKey __num_att, ValueKey __key);

extern ValueKey getRandomValueKey (AttributeKey __num_att);

#endif
