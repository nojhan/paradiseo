

#include <eo>
#include <eoForAymen.h>


//using namespace std;




int
main (int __argc, char *__argv[])
{
	
  // put what you want in this main !
}











